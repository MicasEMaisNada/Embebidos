#include "display.h"
using namespace std;
Display::Display(QObject *parent):QObject(parent)
{
    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));
    qDebug() << "updated successfully";
}

void Display::get_info_database()
{
    qDebug() << "in get_info_database";
    manager->get(QNetworkRequest(QUrl("http://api.thingspeak.com/channels/1280253/feeds.json?api_key=BDJ0QE8EP5FWXBIR&results=2")));
}

QString Display::getPm()
{
    if(pm2_5 < 50) return "Healthy";
    else if(pm2_5 <100)return "Moderate";
    else return "Unhealthy";
}

QString Display::getMotor()
{
    if(motor) return "On";
    else return "Off";
}

void Display::replyFinished(QNetworkReply *reply)
{
    qDebug() << "in reply";
    qDebug() << "readyRead:"<<reply;
    if(reply) {
        QByteArray data = reply->readAll();
        qDebug() << "Response:" << data;
        QJsonDocument jsonDoc = QJsonDocument::fromJson(data);
        QJsonObject root = jsonDoc.object();
        QJsonArray dataObject = root.value("feeds").toArray();
        QJsonValue  value = dataObject.at(1);
        pm2_5 = value["field4"].toInt();
        qDebug() << "PM2.5 :" <<pm2_5;

        motor = value["field5"].toInt();
        qDebug() << "Motor:" <<motor;
    }

   else qDebug() << "Error reading!";
}



