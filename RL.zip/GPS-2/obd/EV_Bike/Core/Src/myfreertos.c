#include "myfreertos.h"
#include "usart.h"
#include "dma.h"
#include <stdlib.h> 
/***************** Macros  ********************/
#define	ERRO_SIZE	16
#define GPS_SIZE  128
#define OBD_SIZE  8
#define SIZE  55
/**************** TASK HANDLERS *****************/
xTaskHandle Sender_um_Handler;
xTaskHandle Sender_dois_Handler;
xTaskHandle Receiver_Handler;
xTaskHandle getLocationHandler;
xTaskHandle parsingGpsHandler;
xTaskHandle controlGpsHandler;
xTaskHandle getPM2_5Handler;
xTaskHandle reinforcementLearningTaskHandler;
/**************** QUEUE HANDLER *****************/
xQueueHandle SimpleQueue;
xQueueHandle dataBaseQueue;
/**************** Semaphore HANDLER *************/
SemaphoreHandle_t gpsSemaphore;
SemaphoreHandle_t pmSemaphore;
SemaphoreHandle_t pmMutex;
/***************** Variables  ********************/
struct dataBase{
		char id;
		char value;
};


struct command{
		char pid;
		char byte_1 ;
	  char byte_2 ;
	  char lenght ;
};
struct car{
		char fuelType;
		char fuelLevel ;
	  char distanceTravelled ;
};

struct coordinates{
	double latitude;
	double longitude;
};
struct rl{
	int state;
  char action;
};
struct rl rl;
struct car car;
struct command command;
struct coordinates coordinates;
enum states {
    start,
	  head,
	  space,
	  byteOne,
	  byteTwo,
	  erro,
	  parsing
} state = start;
enum states nextState, nextNextState = head;
char commandErro[ERRO_SIZE];
int writeErro = 0;
unsigned char gpsBuffer[GPS_SIZE];
unsigned char gpllBuffer[SIZE];
char latitude[ ] = {',','4','1','3','9','.','3','6','5','5','0',',','N',',','0','0','8','3','0','.','2','6','1','6','8',',','W'};
unsigned char longitude[12];
int writeGPS = 0;
int readGPS = 0;
char OBDBuffer[OBD_SIZE];
int writeOBD = 0;
int readOBD = 0;
float pm2_5 = 0;
unsigned char stringGPLL[5] = {'G','P','G','L','L'};
int airArray[8] ={24,26,28,35,12,10,8,4};
char output[8];
float qTable[2][40] = {
{20,20,20,20,20,20,20,20,20,20,20,20,12.2,10.49,8.86549999999996,7.32222499999997,5.85611374999995,4.46330806249995,3.14014265937495,1.8831355264062,0.688978750085893,-0.445470187418402,-1.52319667804748,-2.54703684414511,-3.51968500193786,-4.44370075184097,-5.32151571424892,-6.15543992853648,-6.94766793210965,-7.70028453550418,-8.41527030872898,-9.09450679329253,-9.73978145362792,-10.3527923809465,-13.9351527618992,-14.0133951238043,-14.0877253676141,-14.1583390990618,-14.2254176284329,-14.2704887728866},
{16,16,16,16,16,16,16,16,16,16,16,16,16,14.2,12.49,10.8655,9.32222499999996,7.85611374999996,6.46330806249995,5.14014265937495,3.8831355264062,2.68897875008589,1.5545298125816,0.476803321952519,-0.547036844145108,-1.51968500193785,-2.44370075184096,-3.32151571424892,-4.15543992853648,-4.94766793210966,-5.70028453550418,-6.41527030872898,-7.09450679329253,-7.73978145362791,-8.35279238094653,-8.43515276189921,-8.51339512380426,-8.58772536761406,-8.65833909923337,-8.72542214427169}};
/*************/
	 char degreeLatitude[2], minutosLatitude[10];
	char degreeLongitude[3], minutosLongitude[10];	
	char array[12];
int degreeL;
	  double dLatitute,mLatitute, dLongitude,mLongitude;
	int	aux1;
	const char auxlatitude;
/***************** Function  ********************/
void init_rtos(void){
	
	/**************** Queue Create *************/	
	SimpleQueue = xQueueCreate(5, sizeof(char));
	if(SimpleQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}
	dataBaseQueue=xQueueCreate(7, sizeof(struct dataBase));
	if(dataBaseQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}
	/**************** Semaphore Create *************/
	gpsSemaphore = xSemaphoreCreateCounting(5,0);
	if(gpsSemaphore) printf("GPS:Semaphore Created\r\n");
	else printf("GPS:Semaphore NOT Created\r\n");
	pmSemaphore = xSemaphoreCreateCounting(5,0);
	if(pmSemaphore) printf("PM:Semaphore Created\r\n");
	else printf("PM:Semaphore NOT Created\r\n");
	/**************** Mutex Create *************/
	pmMutex = xSemaphoreCreateMutex();
	if(pmMutex == NULL) printf("PM:Mutex NOT Created\r\n");
	else {
		printf("PM:Mutex Created\r\n");
	  xSemaphoreGive( pmSemaphore ); }
	/**************** Task Create *************/
	xTaskCreate(Send_um_Task,"Um_Send",128,NULL,3,&Sender_um_Handler);
	xTaskCreate(Send_dois_task,"Dois_Send",128,(void *) 111,2,&Sender_dois_Handler);
	xTaskCreate(Receiver_task,"Receive",128,NULL,1, &Receiver_Handler);
  xTaskCreate(getLocationFunction,"getLocation",128,NULL,1, &getLocationHandler);
  xTaskCreate(parsingGpsFunction,"parsingGps",128,NULL,1, &parsingGpsHandler);
	xTaskCreate(controlGpsFunction,"controlGps",128,NULL,1, &controlGpsHandler);
	xTaskCreate(getPM2_5Function,"getPM2_5",128,NULL,1, &getPM2_5Handler);
	xTaskCreate(reinforcementLearningTaskFunction,"reinforcementLearningTask",128,NULL,1, &reinforcementLearningTaskHandler);
	vTaskStartScheduler();

}

void Send_um_Task (void *argument)

{
	uint8_t i;
	char aux;
	uint32_t TickDelay = pdMS_TO_TICKS(500);
	while (1)
	{
		if(uart_get_rxbufsize()!=0)	{
			i= uart_getchar();
			aux = (char) i;
			if (xQueueSend(SimpleQueue, &aux, portMAX_DELAY) != pdPASS)printf(" Unuccessfully sent the number\r\n");
		
		}
		vTaskDelay(TickDelay);
	}
}

void Send_dois_task (void *argument)
{
	struct dataBase theReceiver;
	unsigned char aux;
	while (1)
	{
		if (xQueueReceive(dataBaseQueue, &theReceiver, portMAX_DELAY) == pdTRUE)
		{
			//To send to the uart needs to be in ASCI -> Only for testing
			//Clear 'a' when database implemented
			aux=(unsigned char)theReceiver.value;
			uart_putchar (aux);	
			uart_putchar ('a');
		}}}


void Receiver_task (void *argument)
{
		char auxiliar = 0;
	char received = 0;
	char commandR=0;
	char state, nextState = 0;
	struct dataBase aux;
	while (1)
	{ 
		if (xQueueReceive(SimpleQueue, &received, portMAX_DELAY) == pdTRUE)
		{
			auxiliar = received;
			state = nextState;
			switch(state){
				//----------------------- start -> Concatenate first -------------------------------------------------------------------
				case start:
					commandR = auxiliar;
				  //commandR = commandR << 8;
				  commandR = (auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10) << 4;
				  nextState = nextNextState;
				  break;
			//----------------------- HEAD -> Receive mode+PID (already concatenate)---------------------------------------------------
				case head: 
					commandR |= auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10;
				//	commandR = commandR + auxiliar;
					if((commandR == 0x30) |(commandR == 0x32)| (commandR == 0x52)){
						command.pid = commandR;
						nextState = space;
						nextNextState =byteOne;
					}
					else{
						commandErro[writeErro & (ERRO_SIZE -1)] = commandR;
						nextState = erro;
					}	
				break;
			//----------------------- byteOne -> Receive 1�data (already concatenate)---------------------------------------------------
			case byteOne: 
				commandR |= auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10;
				//commandR = commandR + auxiliar;
			  command.byte_1 = commandR;
			  if(command.pid == 0x32) {  
					nextState = space;
					nextNextState = byteTwo;
				}
			  else {
					nextState = parsing;
				}
			break;
		 //----------------------- space -> To receive the space ' ' ---------------------------------------------------
			case space:
				nextState = start;
				break;
		 //----------------------- byteTwo -> Receive 2�data (already concatenate) if lenght = 2 ---------------------------------------------------
			case byteTwo:
				commandR |= auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10;
			  command.byte_2 = commandR;
				nextState = parsing;
      break;			
			
	  //----------------------- erro -> Receive erro data (no concatenate)---------------------------------------------------
			case erro:
						commandErro[writeErro & (ERRO_SIZE -1)] = auxiliar;
						writeErro++;
						nextState = erro;
						if(auxiliar == 0x0D){
							nextState = start;
							nextNextState = head;
						}
			break;
		 //----------------------- parsing -> Parse, Keep and Send to Queue ---------------------------------------------------
			case parsing:
					if(command.pid == 0x30){
						car.fuelLevel = (100/255)*command.byte_1;
						aux.value = car.fuelLevel;
					}
					if(command.pid == 0x32){
						car.distanceTravelled = (256*command.byte_1)+command.byte_2;
						aux.value = car.distanceTravelled;
					}
					if(command.pid == 0x52){
						car.fuelType = command.byte_1;
						aux.value = car.fuelType;
					}
					aux.id = command.pid - 1;
		     	if (xQueueSend(dataBaseQueue, &aux, portMAX_DELAY) != pdPASS) printf(" Unsuccessfully sent the struct\r\n");
		    	
					nextState = start;
					nextNextState = head;
			break;
			default: break;
}}}}
void controlGpsFunction (void *argument)
{
	uint32_t TickDelay = pdMS_TO_TICKS(9000); //1 minuto
  while(1){
		
	 resumeDMA();
	 //uart_putchar('b');
	 vTaskDelay(TickDelay);
	}}

void getLocationFunction (void *argument)
{
	int i;
	int aux;
	uint8_t aux1,auxArray[5];

	while (1)
	{
    //aux1 = uart_get_rxbufsizeFour();
		while(uart_get_rxbufsizeFour() > 0 ){
			pauseDMA();
			//uart_putchar('b');
      do{
				aux = uart_getcharFour();
				if(aux == -ENODATA) break;
				aux = (unsigned char) aux;
        gpsBuffer[writeGPS & (GPS_SIZE -1) ] = aux; 
				writeGPS++;
				i = aux;
			}
      while(i != 0x0A);
			if (gpsBuffer[readGPS & (GPS_SIZE -1) ] == '$' )
			{
				for(int i = 0; i<5 ; i++){
				readGPS ++;
				auxArray[i]= gpsBuffer[readGPS & (GPS_SIZE -1) ];
//				uart_putchar(auxArray[i]);
				}
				if(memcmp(stringGPLL, auxArray, 5) == 0){
					//uart_putchar('a');
					i = 0;
					while(readGPS != writeGPS)
					{
						readGPS ++;
						gpllBuffer[i]= gpsBuffer[readGPS & (GPS_SIZE -1) ];
//						uart_putchar(gpllBuffer[i]);
						i++;
					}
					
					if( xSemaphoreGive( gpsSemaphore ) != pdTRUE ) printf("GPS:error in give");		
//					uart_putchar('\r');
//			    uart_putchar('\n');
				}
			}
	
			readGPS = writeGPS;
		}
		vTaskDelay(pdMS_TO_TICKS(100));
	}
}

int fillGPS(char * ptr1, char * ptr2, int i, int degrees)
{  
	   int j = 0;
	   char aux = 0 ;
		 while(aux != ',')
		 { j++;
			 aux = gpllBuffer[i];
			 //aux = latitude[i];
			 if( j <= degrees)
			 ptr1[j-1]=aux;
			 else
			 ptr2[j-(1+degrees)]=aux;
			 i++;	
		 }
		 ptr2[j-(1+degrees)]= 0;
			 //ptr[i-2]=gpllBuffer[i];
		 return i;
}

void parsingGpsFunction (void *argument)
{	int i = 0 ;

	while(1){
  if( xSemaphoreTake( gpsSemaphore, portMAX_DELAY ) == pdTRUE ){
	//	 i = fillGPS(latitude, 1);
 //   fillGPS(longitude, i);
		// degreeLatitude = concatenate(latitude[0], latitude[1]);
		
	
		i = fillGPS(degreeLatitude,minutosLatitude,1,2);

		fillGPS(degreeLongitude,minutosLongitude,(i + 2),3);

		 dLatitute = atof (degreeLatitude);
		 mLatitute = atof (minutosLatitude);
		 coordinates.latitude = dLatitute + (mLatitute/60) ;
		 dLongitude = atof (degreeLongitude);
		 mLongitude = atof (minutosLongitude);
		 coordinates.longitude = dLongitude + (mLongitude/60) ;
		 printf("%f /r/n",coordinates.latitude );
     printf("%f /r/n",coordinates.longitude);
//		 aux1 = (int) aux;
//		 coordinates.latitude = aux1 + ((aux1 - aux)/60) ;

		 //coordinates.longitude = atof (longitude);
				
//	 }	
}	
}}
void getPM2_5Function(void *argument)
{
	int i = 0;
	while(1){
//	  if( xSemaphoreTake( pmMutex, portMAX_DELAY ) == pdTRUE ){
  	pm2_5 = airArray[i & 7];
//		xSemaphoreGive( pmMutex );
		i++;
		if( xSemaphoreGive( pmSemaphore ) != pdTRUE ) printf("PM:error in give");
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
}

void reinforcementLearningTaskFunction(void *argument)
{ 
	int i = 0;
	while(1){
		if( xSemaphoreTake( pmSemaphore, portMAX_DELAY ) == pdTRUE ){
//		if( xSemaphoreTake( pmMutex, portMAX_DELAY ) == pdTRUE ){
		rl.state = pm2_5;
//		xSemaphoreGive( pmMutex );
		if(qTable[0][rl.state] > qTable[1][rl.state]) rl.action = 0;
	  else rl.action = 1;
		}
		output[i] = rl.action;
		i++;
		printf("State: %d , Action: %d \r\n",	rl.state,rl.action);
	}
}
