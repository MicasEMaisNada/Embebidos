#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <opencv2/opencv.hpp>
#include <opencv2/video.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <queue>
#include <string>
#include <QDebug>

#include <iostream>
#include <stdio.h>
using namespace cv;
using namespace std;

int main(int argc, char *argv[])
{
    VideoCapture m_camera;
     /*m_camera.set(CV_CAP_PROP_FRAME_WIDTH , 640);
     m_camera.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
     m_camera.set(CV_CAP_PROP_BRIGHTNESS, 100);
     m_camera.set(CV_CAP_PROP_EXPOSURE, 20);
     m_camera.set(CV_CAP_PROP_CONTRAST, 0);
     m_camera.set(CV_CAP_PROP_SATURATION, 0);*/

     m_camera.open(0);
    Mat frame;
    //--- INITIALIZE VIDEOCAPTURE

    // open the default camera using default API
    // cap.open(0);
    // OR advance usage: select any API backend
    //int deviceID = 0;             // 0 = open default camera
    //int apiID = cv::CAP_ANY;      // 0 = autodetect default API
    // open selected camera using selected API
    //cap.open(deviceID, apiID);

    // check if we succeeded
    if (!m_camera.isOpened()) {
        cerr << "ERROR! Unable to open camera\n";
        return -1;
   }
    else{

        qDebug()<<"operacilonal";
        m_camera.read(frame);   //Retrives a frame from the camera video buffer, present on vl4 device driver
        qDebug()<< "tirou foto";
        imwrite("some.jpg", frame);
        m_camera.release();
    }



#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
