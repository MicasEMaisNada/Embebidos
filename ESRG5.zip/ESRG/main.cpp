#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QObject>
#include "display.h"
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
int main(int argc, char *argv[])
{
/*#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif*/
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    QQmlContext* ctx = engine.rootContext();
    //Display display;
    //display.create();
    /* Timer */
    /* use ITIMER_REAL */
    int fd0 = open("/dev/led0",O_WRONLY);
    char on='1';
    write(fd0,&on,1);
    close(fd0);
    struct itimerval itv;
    signal(SIGALRM,obj.timerHandler);
    itv.it_interval.tv_sec = 5;
    itv.it_interval.tv_usec = 0;
    itv.it_value.tv_sec = 5;
    itv.it_value.tv_usec = 0;
    setitimer(ITIMER_REAL,&itv,NULL);


    ctx->setContextProperty("display",&obj);
    //qmlRegisterType<Display>("displayLib",1,0,"Display");

    //display.get_info_database();
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    /*QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);*/
    //engine.rootContext()->setContextProperty("display",display);

    //display.wait();
    engine.load(url);

    if(engine.rootObjects().isEmpty())
       return -1;
    return app.exec();


/*    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
 //   const QUrl url(QStringLiteral("qrc:/main.qml"));
*//*    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);*/
/*    engine.rootContext()->setContextProperty("display",display);
    engine.load(QUrl(QString("qrc:/main.qml")));
    if(engine.rootObjects().isEmpty())
        return -1;
    return app.exec();*/
}
