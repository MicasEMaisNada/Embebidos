#include "display.h"
Display obj;
using namespace std;
Display::Display(QObject *parent):QObject(parent)
{
    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));
    qDebug() << "updated successfully";

    connect(this, SIGNAL(thread()), this, SLOT(get_info_database()));
    create();
}

void Display::get_info_database()
{
    qDebug() << "in get_info_database";
    manager->get(QNetworkRequest(QUrl("http://api.thingspeak.com/channels/1280253/feeds.json?api_key=BDJ0QE8EP5FWXBIR&results=2")));
}

QString Display::getPm()
{
    if(pm2_5 < 50) return "Healthy";
    else if(pm2_5 <100)return "Moderate";
    else return "Unhealthy";
}

QString Display::getMotor()
{
    if(motor) return "On";
    else return "Off";
}

void Display::replyFinished(QNetworkReply *reply)
{
    qDebug() << "in reply";
    qDebug() << "readyRead:"<<reply;
    if(reply) {
        QByteArray data = reply->readAll();
        qDebug() << "Response:" << data;
        QJsonDocument jsonDoc = QJsonDocument::fromJson(data);
        QJsonObject root = jsonDoc.object();
        QJsonArray dataObject = root.value("feeds").toArray();
        QJsonValue  value = dataObject.at(1);
        pm2_5 = value["field4"].toInt();
        qDebug() << "PM2.5 :" <<pm2_5;

        motor = value["field5"].toInt();
        qDebug() << "Motor:" <<motor;
        emit refreshDisplay(getMotor(),getPm());
    }

   else qDebug() << "Error reading!";
}


void Display::wait()
{
    pthread_join(displayID,nullptr);
}

void Display::create()
{   qDebug()<<"inside the thread cretor";
    displayThread.sched_priority = 1;
    pthread_attr_setdetachstate(&displayattr, PTHREAD_CREATE_JOINABLE);
    pthread_attr_setschedparam(&displayattr,&displayThread);
    pthread_attr_init(&displayattr);
    if(pthread_create(&displayID, &displayattr, display_thread, this)) qDebug()<<"error creating thread";

}

void Display::timerHandler(int signo)
{
    if(signo == SIGALRM ){
    //Display *obj = (Display*)signo;
    qDebug()<<"Timer overflow";
    pthread_mutex_lock(&obj.timerConditionMutex);
    obj.timerReceived = 1;
    pthread_cond_signal(&obj.timerCondition);
    pthread_mutex_unlock(&obj.timerConditionMutex);
    }

}

void *Display::display_thread(void * arg)
{
     //Display *obj = (Display*)arg;
     //pthread_mutex_lock(&obj.timerConditionMutex);
     while(1){
     pthread_mutex_lock(&obj.timerConditionMutex);
     while(obj.timerReceived != 1)
        pthread_cond_wait(&obj.timerCondition,&obj.timerConditionMutex);
     obj.timerReceived = 0;
     pthread_mutex_unlock(&obj.timerConditionMutex);
     emit obj.thread();
     //pthread_exit(nullptr);
}}
