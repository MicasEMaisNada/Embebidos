#ifndef DISPLAY_H
#define DISPLAY_H
#include <QObject>
#include <QString>
#include <QtNetwork>
#include <QtDebug>
#include <QJsonDocument>
#include <QJsonValue>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrlQuery>
#include <QMetaType>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
/*
struct carInformation {
    Q_GADGET
    Q_PROPERTY(QString pm2_5 MEMBER pm2_5_)
    Q_PROPERTY(QString motor MEMBER motor_)
public:
    QString pm2_5_;
    QString motor_;

};Q_DECLARE_METATYPE(carInformation)*/

/*
struct carInfo{
    QString motor_;
    QString pm2_5_;
};Q_DECLARE_METATYPE(carInfo)*/

class Display : public QObject
{
    Q_OBJECT

public:

    explicit Display(QObject *parent = nullptr);
    QString getPm();
    QString getMotor();
    void wait();
    void create();
    static void timerHandler(int signo);
signals:
   void refreshDisplay(QString mm, QString mp);
   void thread();
public slots:
    void get_info_database();
    void replyFinished(QNetworkReply *);
private:

    static void *display_thread(void *);
    pthread_t displayID;
    pthread_attr_t displayattr;
    sched_param displayThread;
    pthread_mutex_t timerConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t timerCondition;
    QNetworkAccessManager* manager;
    int timerReceived = 0;
    int pm2_5;
    int motor;
};
extern Display obj;
#endif // DISPLAY_H
