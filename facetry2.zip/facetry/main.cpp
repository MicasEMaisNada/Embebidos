#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <opencv2/opencv.hpp>
#include <string>
#include <QDebug>
#include <iostream>
#include <ctime>
#include <fstream>
#include <map>
using namespace cv;
using namespace std;
int main(int argc, char *argv[])
{
   Ptr<FaceRecognizer> model;
   model = createLBPHFaceRecognizer();

//**************************** TRAIN **************************************************
    // holds images and labels
    vector<Mat> images;
    vector<int> labels;
    // using Mat of type CV_32SC1
    // Mat labels(number_of_samples, 1, CV_32SC1);
    // images for first person
    images.push_back(imread("cris1.jpg", IMREAD_GRAYSCALE)); labels.push_back(0);
    images.push_back(imread("cris2.jpg", IMREAD_GRAYSCALE)); labels.push_back(0);
    images.push_back(imread("cris3.jpg", IMREAD_GRAYSCALE)); labels.push_back(0);
    // images for second person
    images.push_back(imread("sara1.jpg", IMREAD_GRAYSCALE)); labels.push_back(1);
    images.push_back(imread("sara2.jpg", IMREAD_GRAYSCALE)); labels.push_back(1);
    images.push_back(imread("sara3.jpg", IMREAD_GRAYSCALE)); labels.push_back(1);
    model->train(images, labels);
    if((images.size()!=0) && (labels.size()!=0))
        qDebug() << "Treino bem feito" << endl;
    else  qDebug() << "Treino mal feito" << endl;
//*************************** Recognize ************************************************
    //********** DETECTION *************
//1) classificador para detetar caras
    CascadeClassifier m_classifier;
    m_classifier.load("lbpcascade_frontalface.xml");
//2) abrir imagem a ser testada
    Mat windowFrame;
    Mat frame = imread("cris3.jpg");
    if (!frame.empty())
        qDebug() << "go go" << endl;
    // Check for failure
    if (frame.empty())
    {
        qDebug() << "Could not open or find the image" << endl;

        return -1;
     }
//2.1)colocar imagem a preto e branco
    cvtColor(frame, windowFrame, 6);
    //imshow("edges", windowFrame);
//2.2)detetar as caras das fotos
    vector<Rect> faces;
    m_classifier.detectMultiScale(frame, faces, 1.2, 5);
    qDebug() << faces.size() << endl;
// ********** RECONHECER *****************

    //model->cv::FaceRecognizer::read("./recognizer/embeddings.xml");
    for(size_t i = 0; i < faces.size(); i++){
        rectangle(frame, faces[i], Scalar(0, 255, 0));
        Mat face = windowFrame(faces[i]);
        double confidence = 0.0;
        int predicted = model->predict(face);
        //int predicted  = 0;
        model->predict(face, predicted, confidence);
        /*if(labels.find(predicted) == labels.end() || confidence < 25)
           qDebug() << "unknown" << endl;
        else qDebug() << "eureka" << endl;*/
        qDebug() << "ID: " << predicted << " ^Confidence: " << confidence << endl;

}


#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
