#include "pms5003.h"
#include "usart.h"

#define CHAR1 0x42
#define CHAR2 0x4D

volatile uint8_t info_received = 0;
pms_data pms_Data;

typedef enum {
    START1,
    START2,
    LENGTH1,
    LENGTH2,
    DATA,
    CHECK1,
    CHECK2
} State;

typedef struct {
    State  state;
    uint8_t buf[26];
    uint8_t  size;
    uint8_t     index, len;
    uint16_t check, sum;
} Info;

static Info info;

void pms_init(void)
{
    info.state = START1;
    info.size = sizeof(info.buf);
    info.index = info.len = 0;
    info.check = info.sum = 0;
}


uint8_t pms_process(uint8_t byte)
{
//uart_putchar(&uart_3, byte);
    switch (info.state) {
			
    case START1:

        info.sum = byte;
        if (byte == CHAR1) {
            info.state = START2;
        }
        break;
				
    case START2:
        info.sum += byte;
        if (byte == CHAR2) {
            info.state = LENGTH1;
        } 
				else {
            info.state = START1;
           // return pms_process(byte);
        }
        break;

    case LENGTH1:
        info.sum += byte;
        info.len = byte << 8;
        info.state = LENGTH2;
        break;
		
    case LENGTH2:
        info.sum += byte;
        info.len += byte;
        info.len -= 2;     						// exclude checksum bytes
        if (info.len <= 26) {
            info.index = 0;
            info.state = DATA;
        } 
				else {
            info.state = START1;
        }
        break;
    
    case DATA:
        info.sum += byte;
        if (info.index < info.len) {
			//	if (info.index < 0x19) {
            info.buf[info.index++] = byte;
        }
        if (info.index == info.len) {
				//if (info.index == 0x19) {
            info.state = CHECK1;
        }
        break;

    case CHECK1:
        info.check = byte << 8;
        info.state = CHECK2;
        break;

    case CHECK2:
        info.check += byte;
        info.state = START1;
				info_received = 1;
        return (info.check == info.sum);
    default:
        info.state = START1;
        break;
    }
    return -1;
}

static uint16_t get(uint8_t *buf, int index)
{
    uint16_t data;
    data = buf[index] << 8;
    data += buf[index + 1];
    return data;
}

void pms_parsing(pms_data *data)
{
    data->gm3PM1_0_std = get(info.buf, 0);
    data->gm3PM2_5_std = get(info.buf, 2);
    data->gm3PM10_0_std = get(info.buf, 4);
    data->gm3PM1_0_env = get(info.buf, 6);
    data->gm3PM2_5_env = get(info.buf, 8);
    data->gm3PM10_0_env = get(info.buf, 10);
    data->nrGt0_3um = get(info.buf, 12);
    data->nrGt0_5um = get(info.buf, 14);
    data->nrGt1_0um = get(info.buf, 16);
		data->nrGt2_5um = get(info.buf, 18);
    data->nrGt5_0um = get(info.buf, 20);
    data->nrGt10_0um = get(info.buf, 22);
    data->version = info.buf[24];
    data->errorCode  = info.buf[25];
}