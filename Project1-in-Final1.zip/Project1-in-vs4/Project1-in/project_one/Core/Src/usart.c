/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */
#include "myfreertos.h"
#define TBUF_SIZE 128
#define RBUF_SIZE 128
#define RBUFSEVEN_SIZE 256
#define RBUFTWO_SIZE 32
BaseType_t xHigherPriority = pdFALSE; // FALSE because sending the notification DOESN'T cause a ISR to block
xTaskHandle AuxHandler;
static uint8_t aux[20];
static volatile uint8_t controlOut = 0;
static volatile uint8_t controlIn = 0;
// Uart 4
static uint8_t TxBuffFour [TBUF_SIZE];
static uint8_t RxBuffFour [RBUF_SIZE];
static volatile uint8_t TxWriteIndexFour;
static volatile uint8_t TxReadIndexFour;
static volatile uint8_t RxWriteIndexFour;
static volatile uint8_t RxReadIndexFour;
static char ti_restartFour = 1;
// Uart 7
static  uint8_t TxBuffSeven [TBUF_SIZE];
static  uint8_t RxBuffSeven [RBUFSEVEN_SIZE];
static volatile uint8_t TxWriteIndexSeven;
static volatile uint8_t TxReadIndexSeven;
static volatile uint8_t RxWriteIndexSeven;
static volatile uint8_t RxReadIndexSeven;
static char ti_restartSeven = 1;
// Uart 2
static uint8_t TxBuffTwo [TBUF_SIZE];
static uint8_t RxBuffTwo [RBUFTWO_SIZE];
static volatile uint8_t TxWriteIndexTwo;
static volatile uint8_t TxReadIndexTwo;
static volatile uint8_t RxWriteIndexTwo;
static volatile uint8_t RxReadIndexTwo;
static char ti_restartTwo = 1;
// Uart 3
static uint8_t TxBuffThree[TBUF_SIZE];
static uint8_t RxBuffThree [RBUF_SIZE];
static volatile uint8_t TxWriteIndexThree;
static volatile uint8_t TxReadIndexThree;
static volatile uint8_t RxWriteIndexThree;
static volatile uint8_t RxReadIndexThree;
static char ti_restartThree = 1;
// Uart 6
static uint8_t TxBuffSix[TBUF_SIZE];
static uint8_t RxBuffSix [RBUF_SIZE];
static volatile uint8_t TxWriteIndexSix;
static volatile uint8_t TxReadIndexSix;
static volatile uint8_t RxWriteIndexSix;
static volatile uint8_t RxReadIndexSix;
static char ti_restartSix = 1;
/* USER CODE END 0 */

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart7;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;
DMA_HandleTypeDef hdma_uart7_rx;
DMA_HandleTypeDef hdma_usart2_rx;

/* UART4 init function */
void MX_UART4_Init(void){

  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }

}
/* UART7 init function */
void MX_UART7_Init(void){

  huart7.Instance = UART7;
  huart7.Init.BaudRate = 9600;
  huart7.Init.WordLength = UART_WORDLENGTH_8B;
  huart7.Init.StopBits = UART_STOPBITS_1;
  huart7.Init.Parity = UART_PARITY_NONE;
  huart7.Init.Mode = UART_MODE_TX_RX;
  huart7.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart7.Init.OverSampling = UART_OVERSAMPLING_16;
  huart7.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart7.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart7) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART2 init function */

void MX_USART2_UART_Init(void){

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART3 init function */

void MX_USART3_UART_Init(void){

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART6 init function */

void MX_USART6_UART_Init(void){

  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  huart6.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart6.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle){

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspInit 0 */

  /* USER CODE END UART4_MspInit 0 */
    /* UART4 clock enable */
    __HAL_RCC_UART4_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**UART4 GPIO Configuration
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART4;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* UART4 interrupt Init */
    HAL_NVIC_SetPriority(UART4_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspInit 1 */

  /* USER CODE END UART4_MspInit 1 */
  }
  else if(uartHandle->Instance==UART7)
  {
  /* USER CODE BEGIN UART7_MspInit 0 */

  /* USER CODE END UART7_MspInit 0 */
    /* UART7 clock enable */
    __HAL_RCC_UART7_CLK_ENABLE();

    __HAL_RCC_GPIOE_CLK_ENABLE();
    /**UART7 GPIO Configuration
    PE7     ------> UART7_RX
    PE8     ------> UART7_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART7;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    /* UART7 DMA Init */
    /* UART7_RX Init */
    hdma_uart7_rx.Instance = DMA1_Stream3;
    hdma_uart7_rx.Init.Channel = DMA_CHANNEL_5;
    hdma_uart7_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_uart7_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_uart7_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_uart7_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_uart7_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_uart7_rx.Init.Mode = DMA_CIRCULAR;
    hdma_uart7_rx.Init.Priority = DMA_PRIORITY_LOW;
    hdma_uart7_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_uart7_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_uart7_rx);

    /* UART7 interrupt Init */
    HAL_NVIC_SetPriority(UART7_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(UART7_IRQn);
  /* USER CODE BEGIN UART7_MspInit 1 */

  /* USER CODE END UART7_MspInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();

    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PD5     ------> USART2_TX
    PD6     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USART2 DMA Init */
    /* USART2_RX Init */
    hdma_usart2_rx.Instance = DMA1_Stream5;
    hdma_usart2_rx.Init.Channel = DMA_CHANNEL_4;
    hdma_usart2_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_usart2_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart2_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart2_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart2_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart2_rx.Init.Mode = DMA_CIRCULAR;
    hdma_usart2_rx.Init.Priority = DMA_PRIORITY_LOW;
    hdma_usart2_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_usart2_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_usart2_rx);

    /* USART2 interrupt Init */
    HAL_NVIC_SetPriority(USART2_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspInit 0 */

  /* USER CODE END USART3_MspInit 0 */
    /* USART3 clock enable */
    __HAL_RCC_USART3_CLK_ENABLE();

    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**USART3 GPIO Configuration
    PD8     ------> USART3_TX
    PD9     ------> USART3_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USART3 interrupt Init */
    HAL_NVIC_SetPriority(USART3_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspInit 1 */

  /* USER CODE END USART3_MspInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspInit 0 */

  /* USER CODE END USART6_MspInit 0 */
    /* USART6 clock enable */
    __HAL_RCC_USART6_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_USART6;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART6 interrupt Init */
    HAL_NVIC_SetPriority(USART6_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspInit 1 */

  /* USER CODE END USART6_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle){

  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspDeInit 0 */

  /* USER CODE END UART4_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_UART4_CLK_DISABLE();

    /**UART4 GPIO Configuration
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_10|GPIO_PIN_11);

    /* UART4 interrupt Deinit */
    HAL_NVIC_DisableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspDeInit 1 */

  /* USER CODE END UART4_MspDeInit 1 */
  }
  else if(uartHandle->Instance==UART7)
  {
  /* USER CODE BEGIN UART7_MspDeInit 0 */

  /* USER CODE END UART7_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_UART7_CLK_DISABLE();

    /**UART7 GPIO Configuration
    PE7     ------> UART7_RX
    PE8     ------> UART7_TX
    */
    HAL_GPIO_DeInit(GPIOE, GPIO_PIN_7|GPIO_PIN_8);

    /* UART7 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmarx);

    /* UART7 interrupt Deinit */
    HAL_NVIC_DisableIRQ(UART7_IRQn);
  /* USER CODE BEGIN UART7_MspDeInit 1 */

  /* USER CODE END UART7_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PD5     ------> USART2_TX
    PD6     ------> USART2_RX
    */
    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_5|GPIO_PIN_6);

    /* USART2 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmarx);

    /* USART2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspDeInit 0 */

  /* USER CODE END USART3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART3_CLK_DISABLE();

    /**USART3 GPIO Configuration
    PD8     ------> USART3_TX
    PD9     ------> USART3_RX
    */
    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_8|GPIO_PIN_9);

    /* USART3 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspDeInit 1 */

  /* USER CODE END USART3_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspDeInit 0 */

  /* USER CODE END USART6_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART6_CLK_DISABLE();

    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6|GPIO_PIN_7);

    /* USART6 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspDeInit 1 */

  /* USER CODE END USART6_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
//************** UART 4
#pragma disable 
int uart_putcharFour (unsigned char c){

		if(uart_get_txbufsizeFour() >= TBUF_SIZE) return (-ENOBUFS);
			TxBuffFour [TxWriteIndexFour & (TBUF_SIZE -1)]= c ;
		  TxWriteIndexFour++;
		if (ti_restartFour){ 
			ti_restartFour=0;
			HAL_UART_Transmit_IT(&huart4,& TxBuffFour[TxReadIndexFour & (TBUF_SIZE-1)], 1);
			TxReadIndexFour++;}
		return 0;
	}	



#pragma disable 
int uart_getcharFour( )	{ 	
	if(uart_get_rxbufsizeFour()==0)  return (-ENODATA);
	return (RxBuffFour[(RxReadIndexFour++) & (RBUF_SIZE -1)]);
}

#pragma disable 
uint8_t uart_get_rxbufsizeFour()
{
	return ( RxWriteIndexFour - RxReadIndexFour);
}
#pragma disable 
uint8_t uart_get_txbufsizeFour( )
{
	return ( TxWriteIndexFour - TxReadIndexFour);
}
//************** UART 7
#pragma disable 
int uart_putcharSeven (unsigned char c){

		if(uart_get_txbufsizeSeven() >= TBUF_SIZE) return (-ENOBUFS);
			TxBuffSeven [TxWriteIndexSeven & (TBUF_SIZE -1)]= c ;
		  TxWriteIndexSeven++;
		if (ti_restartSeven){ 
			ti_restartSeven=0;
			HAL_UART_Transmit_IT(&huart7,& TxBuffSeven[TxReadIndexSeven & (TBUF_SIZE-1)], 1);
			TxReadIndexSeven++;}
		return 0;
	}	



#pragma disable 
int uart_getcharSeven( )	{ 	
	uint8_t a;
	uint8_t i;
	if(uart_get_rxbufsizeSeven()==0)  return (-ENODATA);
	i = RxReadIndexSeven & (RBUFSEVEN_SIZE -1);
	a = RxBuffSeven[i];
	RxReadIndexSeven++;
	return a;
}

#pragma disable 
uint8_t uart_get_rxbufsizeSeven()
{	
	if(RxReadIndexSeven == 254){
		RxReadIndexSeven = 0;
	  RxWriteIndexSeven = 0;}
	return ( RxWriteIndexSeven - RxReadIndexSeven);
}

#pragma disable 
uint8_t uart_get_txbufsizeSeven( )
{
	return ( TxWriteIndexSeven - TxReadIndexSeven);
}
//************** UART 2
#pragma disable 
int uart_putcharTwo (unsigned char c){

		if(uart_get_txbufsizeTwo() >= TBUF_SIZE) return (-ENOBUFS);
			TxBuffTwo [TxWriteIndexTwo & (TBUF_SIZE -1)]= c ;
		  TxWriteIndexTwo++;
		if (ti_restartTwo){ 
			ti_restartTwo=0;
			HAL_UART_Transmit_IT(&huart2,& TxBuffTwo[TxReadIndexTwo & (TBUF_SIZE-1)], 1);
			TxReadIndexTwo++;}
		return 0;
	}	



#pragma disable 
int uart_getcharTwo( )	{ 	
	if(uart_get_rxbufsizeTwo()==0)  return (-ENODATA);
	return (RxBuffTwo[(RxReadIndexTwo++) & (RBUFTWO_SIZE -1)]);
}

#pragma disable 
uint8_t uart_get_rxbufsizeTwo()
{		if(RxReadIndexTwo == 31){
		RxReadIndexTwo = 0;
	  RxWriteIndexTwo = 0;}
	return ( RxWriteIndexTwo - RxReadIndexTwo);
}

#pragma disable 
uint8_t uart_get_txbufsizeTwo( )
{
	return ( TxWriteIndexTwo - TxReadIndexTwo);
}

//************** UART 3
#pragma disable 
int uart_putcharThree (unsigned char c){

		if(uart_get_txbufsizeThree () >= TBUF_SIZE) return (-ENOBUFS);
			TxBuffThree  [TxWriteIndexThree  & (TBUF_SIZE -1)]= c ;
		  TxWriteIndexThree ++;
		if (ti_restartThree ){ 
			ti_restartThree =0;
			HAL_UART_Transmit_IT(&huart3,& TxBuffThree [TxReadIndexThree  & (TBUF_SIZE-1)], 1);
			TxReadIndexThree ++;}
		return 0;
	}	



#pragma disable 
int uart_getcharThree( )	{ 	
	if(uart_get_rxbufsizeThree()==0)  return (-ENODATA);
	return (RxBuffThree[(RxReadIndexThree++) & (RBUF_SIZE -1)]);
}

#pragma disable 
uint8_t uart_get_rxbufsizeThree()
{	
	return ( RxWriteIndexThree - RxReadIndexThree);
}

#pragma disable 
uint8_t uart_get_txbufsizeThree( )
{
	return ( TxWriteIndexThree - TxReadIndexThree);
}
//************** UART 6
#pragma disable 
int uart_putcharSix (unsigned char c){

		if(uart_get_txbufsizeSix () >= TBUF_SIZE) return (-ENOBUFS);
			TxBuffSix  [TxWriteIndexSix  & (TBUF_SIZE -1)]= c ;
		  TxWriteIndexSix ++;
		if (ti_restartSix ){ 
			ti_restartSix =0;
			HAL_UART_Transmit_IT(&huart6,& TxBuffSix [TxReadIndexSix & (TBUF_SIZE-1)], 1);
			TxReadIndexSix ++;}
		return 0;
	}	



#pragma disable 
int uart_getcharSix( )	{ 	
	if(uart_get_rxbufsizeSix()==0)  return (-ENODATA);
	return (RxBuffSix[(RxReadIndexSix++) & (RBUF_SIZE -1)]);
}

#pragma disable 
uint8_t uart_get_rxbufsizeSix()
{	
	return ( RxWriteIndexSix - RxReadIndexSix);
}

#pragma disable 
uint8_t uart_get_txbufsizeSix( )
{
	return ( TxWriteIndexSix - TxReadIndexSix);
}

//-----------------------------------------------------
void init_UARTS(){
	HAL_UART_Receive_IT(&huart3,&RxBuffThree[RxWriteIndexThree], 1);
	HAL_UART_Receive_DMA(&huart2,&RxBuffTwo[RxWriteIndexTwo], 32);
	HAL_UART_Receive_IT(&huart6,&RxBuffSix[RxWriteIndexSix], 1); 
	//HAL_UART_Receive_IT(&huart4,&bt, 1); 
	HAL_UART_Receive_IT(&huart4,&RxBuffFour[RxWriteIndexFour], 1); 
  HAL_UART_Receive_DMA(&huart7,&RxBuffSeven[RxWriteIndexSeven], 256); 
	controlOut = 1;
}
//implemantation of UART ISR
void HAL_UART_RxCpltCallback(UART_HandleTypeDef* huart){
//	if (huart->Instance == USART3){ 
//		RxWriteIndexThree++ ;
//		HAL_UART_Receive_IT(&huart3, &RxBuffThree[RxWriteIndexThree  & (RBUF_SIZE-1)], 1); //TO testing during implementation
//	}
//	
//	if (huart->Instance == USART6){ 
//		RxWriteIndexSix ++ ;
//		HAL_UART_Receive_IT(&huart6, &RxBuffSix[RxWriteIndexSix  & (RBUF_SIZE-1)], 1);
//		}
	if (huart->Instance == UART4){ 
		controlIn = 1;
		RxWriteIndexFour ++ ;
		HAL_UART_Receive_IT(&huart4, &RxBuffFour[RxWriteIndexFour  & (RBUF_SIZE-1)], 1);
		AuxHandler = getOBDHandler;
	}
	
	if (huart->Instance == USART2){
		RxWriteIndexTwo = 31 ;		
		controlIn = 1;
		HAL_UART_Receive_DMA(&huart2, &RxBuffTwo[RxWriteIndexTwo  & (RBUFTWO_SIZE-1)], 32);
		AuxHandler = getPM2_5Handler;
	}
	
	if (huart->Instance == UART7){
		RxWriteIndexSeven = 255 ;	
		controlIn = 1;
		HAL_UART_Receive_DMA(&huart7, &RxBuffSeven[RxWriteIndexSeven], 256);
		AuxHandler = getLocationHandler;
	}
	if(controlOut & controlIn ){
//		controlIn = 0;
		vTaskNotifyGiveFromISR(AuxHandler,&xHigherPriority);
		portYIELD_FROM_ISR( xHigherPriority );}
}

void HAL_UART_TxCpltCallback (UART_HandleTypeDef *huart){

		if (huart->Instance == USART3){ 
		if(uart_get_txbufsizeThree() !=0){
			ti_restartThree=0;
			HAL_UART_Transmit_IT(&huart3,&TxBuffThree[TxReadIndexThree & (TBUF_SIZE-1)], 1);
			TxReadIndexThree ++;
		}
		else 
			ti_restartThree=1;
	}

		if (huart->Instance == UART4){ 
		if(uart_get_txbufsizeFour( ) !=0){
			ti_restartFour=0;
			HAL_UART_Transmit_IT(&huart4,&TxBuffFour[TxReadIndexFour & (TBUF_SIZE-1)], 1);
			TxReadIndexFour ++;
		}
		else 
			ti_restartFour=1;
	}

		if (huart->Instance == USART6){ 
		if(uart_get_txbufsizeSix( ) !=0){
			ti_restartSix=0;
			HAL_UART_Transmit_IT(&huart6,&TxBuffSix[TxReadIndexSix & (TBUF_SIZE-1)], 1);
			TxReadIndexSix ++;
		}
		else 
			ti_restartSix=1;
	}
		
	if (huart->Instance == USART2){ 
		if(uart_get_txbufsizeTwo( ) !=0){
			ti_restartTwo=0;
			HAL_UART_Transmit_IT(&huart2,& TxBuffTwo[TxReadIndexTwo & (TBUF_SIZE-1)], 1);
	    TxReadIndexTwo ++;
		}
		else 
			ti_restartTwo=1;
	}
	
	if (huart->Instance == UART7){ 
		if(uart_get_txbufsizeSeven() !=0){
			ti_restartSeven=0;
			HAL_UART_Transmit_IT(&huart7,& TxBuffSeven[TxReadIndexSeven & (TBUF_SIZE-1)], 1);
			TxReadIndexSeven ++;
		}
		else 
			ti_restartSeven=1;
	}
}

//redifine the stdout
int fputc(int ch, FILE *f){
	static int i=0;
	HAL_UART_Transmit(&huart6, (uint8_t*)&ch, 1, 100);
	aux[i]= ch;
	i++;
	return ch;
}

#pragma disable 
void pauseDMA(void){
	 HAL_UART_DMAPause	(&huart7);	

}
#pragma disable 
void resumeDMA(void){
		HAL_UART_DMAResume	(&huart7);
}
#pragma disable 
void pauseDMATwo(void){
	 HAL_UART_DMAPause	(&huart2);	

}
#pragma disable 
void resumeDMATwo(void){
		HAL_UART_DMAResume	(&huart2);
}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
