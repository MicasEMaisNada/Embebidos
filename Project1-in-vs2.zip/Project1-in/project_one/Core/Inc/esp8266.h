#ifndef __esp8266_H__
#define __esp8266_H__


void send_AT(void);
void send_RST(void);
void get_Firmware(void);
void set_Mode(unsigned char nr);
void Wifi_list(void);
void Wifi_Connect(void);
void connect(void);
void set_ClientID(void);

#endif 
