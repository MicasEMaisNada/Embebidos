#ifndef __myfreertos_H__
#define __myfreertos_H__

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "usart.h"
#include "string.h"
#include "stdio.h"

///**************** TASK HANDLERS *****************/
extern xTaskHandle getSmokeHandler;
extern xTaskHandle getOBDHandler;
extern xTaskHandle getPM2_5Handler;
void publishDataFunction(void *argument);
void getOBDFunction (void *argument);
void parsingOBDFunction(void *argument);
void requestOBDFunction (void *argument);
void getLocationFunction (void *argument);
void parsingGpsFunction (void *argument);
void controlGpsFunction (void *argument);
void init_rtos(void);
void controlPM2_5Function (void *argument );
void getPM2_5Function(void *argument );
void reinforcementLearningTaskFunction(void *argument );
void getSmokeFunction(void *argument);
#endif /*__ myfreertos_H_ */
