#include "myfreertos.h"
#include "usart.h"
#include "esp8266.h"
#include "myfreertos.h"
#include "pms5003.h"
#include "usart.h"
#include "dma.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/***************** Macros  ********************/
#define	ERRO_SIZE	16
#define GPS_SIZE  128
#define OBD_SIZE  8
#define SIZE  55
#define MOTOR 1
#define PM 2
#define LATITUDE 3
#define LONGITUDE 4
#define SMOKE 5
/**************** TASK HANDLERS *****************/
xTaskHandle getOBDHandler;
xTaskHandle publishDataHandler;
xTaskHandle parsingOBDHandler;
xTaskHandle requestOBDHandler;
xTaskHandle getLocationHandler;
xTaskHandle parsingGpsHandler;
xTaskHandle controlGpsHandler;
xTaskHandle getPM2_5Handler;
xTaskHandle controlPM2_5Handler;
xTaskHandle reinforcementLearningTaskHandler;
xTaskHandle getSmokeHandler;
/**************** QUEUE HANDLER *****************/
xQueueHandle SimpleQueue;
xQueueHandle dataBaseQueue;
/**************** Semaphore HANDLER *************/
SemaphoreHandle_t gpsSemaphore;
SemaphoreHandle_t pmSemaphore;
SemaphoreHandle_t pmMutex;
/***************** Variables  ********************/
struct dataBase{
		char id;
		double value;
};



struct command{
		char pid;
		char byte_1 ;
	  char byte_2 ;
	  char lenght ;
};
struct car{
		double fuelType;
		double fuelLevel ;
	  double distanceTravelled ;
};

struct coordinates{
	double latitude;
	double longitude;
};
struct rl{
	int state;
  char action;
};
struct rl rl;
struct car car;
struct command command;
struct coordinates coordinates;
enum states {
    start,
	  head,
	  space,
	  byteOne,
	  byteTwo,
	  erro,
	  parsing
} state = start;
enum states State = start;
enum states	nextState,nextNextState = head;
char commandErro[ERRO_SIZE];
int writeErro = 0;
unsigned char gpsBuffer[GPS_SIZE];
unsigned char gpllBuffer[SIZE];
char latitude[ ] = {',','4','1','3','9','.','3','6','5','5','0',',','N',',','0','0','8','3','0','.','2','6','1','6','8',',','W'};
unsigned char longitude[12];
int writeGPS = 0;
int readGPS = 0;
char OBDBuffer[OBD_SIZE];
int writeOBD = 0;
int readOBD = 0;
char pm2_5 = 0;
unsigned char stringGPLL[5] = {'G','P','G','L','L'};
char airArray[8] ={24,26,28,35,12,10,8,4};
char output[8];
float qTable[2][300] = {
{20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,12.2,10.49,8.8655,7.322225,5.85611374999999,4.46330806249999,3.14014265937499,1.88313552640624,0.688978750085928,-0.445470187418368,-1.52319667804745,-2.54703684414508,-3.51968500193782,-4.44370075184094,-5.3215157142489,-6.15543992853646,-6.94766793210965,-7.70028453550416,-8.41527030872896,-9.09450679329251,-9.7397814536279,-10.3527923809465,-10.9351527618992,-11.4883951238042,-12.013975367614,-12.5132765992334,-12.9876127692717,-13.4382321308081,-13.8663205242677,-14.2730044980543,-14.6593542731516,-15.026386559494,-15.3750672315193,-15.7063138699434,-16.0209981764462,-16.3199482676239,-16.6039508542427,-16.8737533115306,-17.1300656459541,-17.3735623636564,-17.6048842454736,-17.8246400331999,-18.0334080315399,-18.231737629963,-18.4201507484648,-18.5991432110416,-18.7691860504896,-18.9307267479651,-19.0841904105668,-22.2299808900385,-21.8934818455366,-21.5738077532598,-21.2701173655968,-20.981611497317,-20.7075309224512,-20.4471543763286,-20.1997966575122,-19.9648068246366,-19.7415664834048,-19.5294881592345,-19.3280137512729,-19.1366130637092,-18.9547824105238,-18.7820432899976,-18.6179411254977,-18.4620440692228,-18.3139418657617,-18.1732447724736,-18.0395825338499,-17.9126034071574,-17.7919732367996,-17.6773745749596,-17.5685058462117,-17.4650805539011,-17.366826526206,-17.2734851998958,-17.184810939901,-17.1005703929059,-17.0205418732607,-16.9445147795976,-16.8722890406178,-16.8036745885869,-16.7384908591575,-16.6765663161997,-16.6177380003897,-16.5618511003702,-16.5087585453517,-16.4583206180841,-16.4104045871799,-16.364884357821,-16.3216401399299,-16.2805581329334,-16.2415302262868,-16.2044537149724,-16.1692310292238,-16.1357694777627,-16.1039810038745,-16.0737819536808,-16.0450928559968,-16.017838213197,-15.9919463025371,-15.9673489874103,-15.9439815380398,-15.9217824611378,-15.9006933380809,-15.8806586711769,-15.861625737618,-15.8435444507371,-15.8263672282003,-15.8100488667903,-15.7945464234508,-15.7798191022782,-15.7658281471643,-15.7525367398061,-15.7399099028158,-15.727914407675,-15.7165186872913,-15.7056927529267,-15.6954081152804,-15.6856377095164,-15.6763558240406,-15.6675380328385,-15.6591611311966,-15.6512030746368,-15.643642920905,-15.6364607748597,-15.6296377361168,-15.6231558493109,-15.6169980568454,-15.6111481540032,-15.605590746303,-15.6003112089879,-15.5952956485385,-15.5905308661116,-15.586004322806,-15.5817041066657,-15.5776189013324,-15.5737379562658,-15.5700510584525,-15.5665485055299,-15.5632210802534,-15.5600600262407,-15.5570570249287,-15.5542041736823,-15.5514939649982,-15.5489192667483,-15.5464733034109,-15.5441496382404,-15.5419421563283,-15.5398450485119,-15.5378527960864,-15.535960156282,-15.5341621484679,-15.5324540410446,-15.5308313389923,-15.5292897720428,-15.5278252834406,-15.5264340192686,-15.5251123183052,-15.5238567023899,-15.5226638672704,-15.5215306739069,-15.5204541402116,-15.519431433201,-15.518459861541,-15.5175368684639,-15.5166600250407,-15.5158270237887,-15.5150356725993,-15.5142838889693,-15.5135696945209,-15.5128912097948,-15.5122466493051,-15.5116343168398,-15.5110526009979,-15.510499970948,-15.5099749724006,-15.5094762237806,-15.5090024125915,-15.508552291962,-15.5081246773639,-15.5077184434957,-15.5073325213209,-15.5069658952549,-15.5066176004921,-15.5062867204675,-15.5059723844442,-15.505673765222,-15.5053900769609,-15.5051205731129,-15.5048645444572,-15.5046213172344,-15.5043902513727,-15.504170738804,-15.5039622018638,-15.5037640917707,-15.5035758871821,-15.503397092823,-15.5032272381819,-15.5030658762728,-15.5029125824592,-15.5027669533362,-15.5026286056694,-15.5024971753859,-15.5023723166167,-15.5022537007859,-15.5021410157466,-15.5020339649592,-15.5019322667113,-15.5018356533757,-15.501743870707,-15.5016566771716,-15.501573843313,-15.5014951511474,-15.5014203935901,-15.5013493739106,-15.501281905215,-15.5012178099543,-15.5011569194566,-15.5010990734838,-15.5010441198096,-15.5009919138191,-15.5009423181282,-15.5008952022217,-15.5008504421107,-15.5008079200051,-15.5007675240049,-15.5007291478047,-15.5006926904145,-15.5006580558937,-15.5006251530991,-15.5005938954441,-15.5005642006719,-15.5005359906382,-15.5005091911063,-15.5004837315508,-15.5004595449378,-15.5004365677217,-15.5004147392894,-15.5003939914266,-15.5003742500062,-15.5003553570914,-15.5003377827726,-15.5003184984333,-15.4998234642585,-15.5000855106609,-15.4933442958743,-15.4922606091195,-15.4011955696009,-14.8546204611634},
{16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,14.2,12.49,10.8655,9.32222499999999,7.85611374999999,6.46330806249999,5.14014265937499,3.88313552640624,2.68897875008593,1.55452981258163,0.476803321952551,-0.547036844145078,-1.51968500193783,-2.44370075184094,-3.3215157142489,-4.15543992853646,-4.94766793210964,-5.70028453550416,-6.41527030872896,-7.09450679329252,-7.7397814536279,-8.35279238094651,-8.93515276189919,-9.48839512380425,-10.0139753676141,-10.5132765992334,-10.9876127692717,-11.4382321308081,-11.8663205242677,-12.2730044980543,-12.6593542731516,-13.026386559494,-13.3750672315193,-13.7063138699434,-14.0209981764462,-14.3199482676239,-14.6039508542427,-14.8737533115306,-15.1300656459541,-15.3735623636564,-15.6048842454736,-15.8246400331999,-16.0334080315399,-16.231737629963,-16.4201507484648,-16.5991432110416,-16.7691860504895,-16.9307267479651,-17.0841904105669,-16.7299808900385,-16.3934818455366,-16.0738077532598,-15.7701173655968,-15.481611497317,-15.2075309224512,-14.9471543763286,-14.6997966575122,-14.4648068246366,-14.2415664834048,-14.0294881592345,-13.8280137512728,-13.6366130637092,-13.4547824105238,-13.2820432899976,-13.1179411254977,-12.9620440692228,-12.8139418657617,-12.6732447724736,-12.5395825338499,-12.4126034071574,-12.2919732367996,-12.1773745749596,-12.0685058462116,-11.9650805539011,-11.866826526206,-11.7734851998957,-11.684810939901,-11.6005703929059,-11.5205418732606,-11.4445147795976,-11.3722890406177,-11.3036745885869,-11.2384908591575,-11.1765663161997,-11.1177380003897,-11.0618511003702,-11.0087585453517,-10.9583206180841,-10.9104045871799,-10.864884357821,-10.8216401399299,-10.7805581329334,-10.7415302262868,-10.7044537149724,-10.6692310292238,-10.6357694777626,-10.6039810038745,-10.5737819536808,-10.5450928559968,-10.5178382131969,-10.4919463025371,-10.4673489874103,-10.4439815380398,-10.4217824611378,-10.4006933380809,-10.3806586711769,-10.361625737618,-10.3435444507371,-10.3263672282003,-10.3100488667903,-10.2945464234508,-10.2798191022782,-10.2658281471643,-10.2525367398061,-10.2399099028158,-10.227914407675,-10.2165186872913,-10.2056927529267,-10.1954081152804,-10.1856377095164,-10.1763558240406,-10.1675380328385,-10.1591611311966,-10.1512030746368,-10.143642920905,-10.1364607748597,-10.1296377361168,-10.1231558493109,-10.1169980568454,-10.1111481540031,-10.105590746303,-10.1003112089879,-10.0952956485385,-10.0905308661116,-10.086004322806,-10.0817041066657,-10.0776189013324,-10.0737379562658,-10.0700510584525,-10.0665485055299,-10.0632210802534,-10.0600600262407,-10.0570570249287,-10.0542041736823,-10.0514939649982,-10.0489192667483,-10.0464733034109,-10.0441496382404,-10.0419421563284,-10.0398450485119,-10.0378527960863,-10.035960156282,-10.034162148468,-10.0324540410446,-10.0308313389924,-10.0292897720427,-10.0278252834406,-10.0264340192686,-10.0251123183052,-10.0238567023899,-10.0226638672704,-10.0215306739069,-10.0204541402116,-10.019431433201,-10.018459861541,-10.0175368684639,-10.0166600250407,-10.0158270237887,-10.0150356725993,-10.0142838889693,-10.0135696945209,-10.0128912097948,-10.0122466493051,-10.0116343168398,-10.0110526009979,-10.010499970948,-10.0099749724006,-10.0094762237806,-10.0090024125915,-10.008552291962,-10.0081246773639,-10.0077184434957,-10.0073325213209,-10.0069658952549,-10.0066176004921,-10.0062867204675,-10.0059723844442,-10.005673765222,-10.0053900769609,-10.0051205731128,-10.0048645444572,-10.0046213172344,-10.0043902513727,-10.004170738804,-10.0039622018638,-10.0037640917707,-10.0035758871821,-10.003397092823,-10.0032272381819,-10.0030658762728,-10.0029125824592,-10.0027669533362,-10.0026286056694,-10.002497175386,-10.0023723166167,-10.0022537007858,-10.0021410157466,-10.0020339649593,-10.0019322667113,-10.0018356533757,-10.001743870707,-10.0016566771716,-10.0015738433131,-10.0014951511474,-10.00142039359,-10.0013493739106,-10.001281905215,-10.0012178099543,-10.0011569194566,-10.0010990734838,-10.0010441198096,-10.0009919138191,-10.0009423181282,-10.0008952022218,-10.0008504421107,-10.0008079200052,-10.0007675240049,-10.0007291478047,-10.0006926904145,-10.0006580558938,-10.0006251530991,-10.0005938954441,-10.0005642006719,-10.0005359906384,-10.0005091911064,-10.0004837315511,-10.0004595449736,-10.0004365677249,-10.0004147393387,-10.0003940023717,-10.0003743022531,-10.0003555871405,-10.0003378077834,-10.0003209173943,-10.0003048715246,-10.0002896279483,-10.0002751465509,-10.0002613892234,-10.0002483197622}};
/*************/
	char degreeLatitude[3], minutosLatitude[10];
	char degreeLongitude[3], minutosLongitude[10];	
	char array[12];
  int degreeL;
	double dLatitute,mLatitute, dLongitude,mLongitude;
	char directionLatitude,directionLongitude;
	int	aux1;
	const char auxlatitude;
	union doubleChar {
	double a;
  char str[8];
};
	char *pointer;
char receive_buffer[8];
/***************** Function  ********************/
void init_rtos(void){
	
	/**************** Queue Create *************/	
	SimpleQueue = xQueueCreate(5, sizeof(char));
	if(SimpleQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}
	dataBaseQueue=xQueueCreate(7, sizeof(struct dataBase));
	if(dataBaseQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}
	/**************** Semaphore Create *************/
	gpsSemaphore = xSemaphoreCreateCounting(5,0);
	if(gpsSemaphore) printf("GPS:Semaphore Created\r\n");
	else printf("GPS:Semaphore NOT Created\r\n");
	pmSemaphore = xSemaphoreCreateCounting(5,0);
	if(pmSemaphore) printf("PM:Semaphore Created\r\n");
	else printf("PM:Semaphore NOT Created\r\n");
	/**************** Mutex Create *************/
	pmMutex = xSemaphoreCreateMutex();
	if(pmMutex == NULL) printf("PM:Mutex NOT Created\r\n");
	else {
		printf("PM:Mutex Created\r\n");
	  xSemaphoreGive( pmSemaphore ); }
	/**************** Task Create *************/
	xTaskCreate(getOBDFunction,"getOBD",128,NULL,3,&getOBDHandler);
	xTaskCreate(publishDataFunction,"publishData",128,(void *) 111,2,&publishDataHandler);
	xTaskCreate(parsingOBDFunction ,"parsingOBD",128,NULL,1, &parsingOBDHandler);
  xTaskCreate(getLocationFunction,"getLocation",128,NULL,1, &getLocationHandler);
  xTaskCreate(parsingGpsFunction,"parsingGps",128,NULL,1, &parsingGpsHandler);
	xTaskCreate(controlGpsFunction,"controlGps",128,NULL,1, &controlGpsHandler);
	xTaskCreate(getPM2_5Function,"getPM2_5",128,NULL,1, &getPM2_5Handler);
	xTaskCreate(reinforcementLearningTaskFunction,"reinforcementLearningTask",128,NULL,1, &reinforcementLearningTaskHandler);
	xTaskCreate(getSmokeFunction,"getSmoke",128,NULL,2, &getSmokeHandler);
	xTaskCreate(requestOBDFunction,"requestOBD",128,NULL,2, &requestOBDHandler);
	xTaskCreate(controlPM2_5Function,"controlPM2_5",128,NULL,1, &controlPM2_5Handler); 
	vTaskStartScheduler();

}

//***************** MQTT communication ************************

void publishDataFunction (void *argument){
	struct dataBase theReceiver;
  union doubleChar aux;
	double a = 654230;
	while (1)
	{
		if (xQueueReceive(dataBaseQueue, &theReceiver, portMAX_DELAY) == pdTRUE)
		{
//			printf(" %d , %f \r\n", theReceiver.id,theReceiver.value);
				uart_putcharThree(theReceiver.id);
//				pointer = (char *)&a;
				memcpy(&a, receive_buffer, sizeof a);
//				aux.a = theReceiver.value;
//				for(int i=0;i<9;i++){
////					uart_putcharThree(aux.str[i]);
//					printf(" %d ", *pointer);
//					pointer++;
//				}
				uart_putcharThree('\r');
//				printf(" \r\n ");
			
//-------------------- MQTT communication --------------------------------------
			
		}}}

//*********************** OBD **********************************
void getOBDFunction (void *argument){
	uint8_t i;
	char aux;
	uint32_t TickDelay = pdMS_TO_TICKS(500);
	while (1)
	{
		if(ulTaskNotifyTake( pdTRUE, portMAX_DELAY )== pdTRUE ){
		while(uart_get_rxbufsizeFour()!=0)	{
			i= uart_getcharFour();
			aux = (char) i;
//			printf("%c",aux);
			if (xQueueSend(SimpleQueue, &aux, portMAX_DELAY) != pdPASS)printf(" Unuccessfully sent the number\r\n");
		
		}
		//vTaskDelay(TickDelay);
	}
}}
void requestOBDFunction (void *argument){
	uint32_t TickDelay = pdMS_TO_TICKS(70000);
	unsigned char distance[7] = {'0','1',' ','3','1','\r','\n'};
	while (1)
	{
		for(int i = 0; i<7 ; i++)
			uart_putcharFour(distance[i]);
		vTaskDelay(TickDelay);
	}
}

void parsingOBDFunction (void *argument){
	char auxiliar = 0;
	char received = 0;
	char commandR=0;
	char echo = 1;
	struct dataBase aux;
	while (1)
	{ 
		if (xQueueReceive(SimpleQueue, &received, portMAX_DELAY) == pdTRUE)
		{
			auxiliar = received;
			state = nextState;
			switch(state){
				//----------------------- start -> Concatenate first -------------------------------------------------------------------
				case start:
					commandR = auxiliar;
				  //commandR = commandR << 8;
				  commandR = (auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10) << 4;
				  nextState = nextNextState;
				  break;
			//----------------------- HEAD -> Receive mode+PID (already concatenate)---------------------------------------------------
				case head: 
					commandR |= auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10;
				//	commandR = commandR + auxiliar;
				  if(echo){ 
						echo = 0;
					  nextState = space;
						nextNextState = head;}
					else {
						if((commandR == 0x2F) |(commandR == 0x31)| (commandR == 0x51)){
							command.pid = commandR;
							nextState = space;
							nextNextState =byteOne;}
						else{
							commandErro[writeErro & (ERRO_SIZE -1)] = commandR;
							nextState = erro;	}	
						echo = 1;}
				break;
			//----------------------- byteOne -> Receive 1�data (already concatenate)---------------------------------------------------
			case byteOne: 
				commandR |= auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10;
				//commandR = commandR + auxiliar;
			  command.byte_1 = commandR;
			  if(command.pid == 0x31) {  
					nextState = space;
					nextNextState = byteTwo;
				}
			  else {
					nextState = parsing;
				}
			break;
		 //----------------------- space -> To receive the space ' ' ---------------------------------------------------
			case space:
				nextState = start;
				break;
		 //----------------------- byteTwo -> Receive 2�data (already concatenate) if lenght = 2 ---------------------------------------------------
			case byteTwo:
				commandR |= auxiliar <= '9' ? auxiliar - '0' : toupper(auxiliar) - 'A' + 10;
			  command.byte_2 = commandR;
				nextState = parsing;
      break;			
			
	  //----------------------- erro -> Receive erro data (no concatenate)---------------------------------------------------
			case erro:
						commandErro[writeErro & (ERRO_SIZE -1)] = auxiliar;
						writeErro++;
						nextState = erro;
						if(auxiliar == 0x0D){
							nextState = start;
							nextNextState = head;
						}
			break;
		 //----------------------- parsing -> Parse, Keep and Send to Queue ---------------------------------------------------
			case parsing:
					if(command.pid == 0x2F){
						car.fuelLevel = (double)((100/255)*command.byte_1);
						aux.value = car.fuelLevel;
					}
					if(command.pid == 0x31){
						car.distanceTravelled = (double)((256*command.byte_1)+command.byte_2);
						aux.value = car.distanceTravelled;
					}
					if(command.pid == 0x51){
						car.fuelType = (double)command.byte_1;
						aux.value = car.fuelType;
					}
					aux.id = command.pid;
		     	if (xQueueSend(dataBaseQueue, &aux, portMAX_DELAY) != pdPASS) printf(" Unsuccessfully sent the struct\r\n");
		    	
					nextState = start;
					nextNextState = head;
			break;
			default: break;
}}}}

//*********************** GPS **********************************

void controlGpsFunction (void *argument){
	uint32_t TickDelay = pdMS_TO_TICKS(9000); //1 minuto
  while(1){
		
	 resumeDMA();
	 //uart_putchar('b');
	 vTaskDelay(TickDelay);
	}}

void getLocationFunction (void *argument){
	int i;
	int aux;
	uint8_t auxArray[5];

	while (1)
	{
		while(uart_get_rxbufsizeSeven() > 0 ){
			pauseDMA();
      do{
   			aux = uart_getcharSeven();
				if(aux == -ENODATA) break;
        gpsBuffer[writeGPS & (GPS_SIZE -1) ] = (unsigned char) aux;
				writeGPS++;
				i = aux;
			}

      while(i != 0x0A);
			if (gpsBuffer[readGPS & (GPS_SIZE -1) ] == '$' )
			{
				for(int i = 0; i<5 ; i++){
				readGPS ++;
				auxArray[i]= gpsBuffer[readGPS & (GPS_SIZE -1) ];
//				uart_putchar(auxArray[i]);
				}
				if(memcmp(stringGPLL, auxArray, 5) == 0){
					//uart_putchar('a');
					i = 0;
					while(readGPS != writeGPS)
					{
						readGPS ++;
						gpllBuffer[i]= gpsBuffer[readGPS & (GPS_SIZE -1) ];
//						uart_putchar(gpllBuffer[i]);
						i++;
					}
					
					if( xSemaphoreGive( gpsSemaphore ) != pdTRUE ) printf("GPS:error in give");		
//					uart_putchar('\r');
//			    uart_putchar('\n');
				}
			}
	
			readGPS = writeGPS;
		}
		vTaskDelay(pdMS_TO_TICKS(100));
	}
}

int fillGPS(char * ptr1, char * ptr2, int i, int degrees, char * direction){  
	   int j = 0;
	   char aux = 0 ;
		 while(aux != ','){ 
			 j++;
       aux = gpllBuffer[i];
			 //aux = latitude[i];
			 if( j <= degrees)
			 ptr1[j-1]=aux;
			 else
			 ptr2[j-(1+degrees)]=aux;
			 i++;	
		 }
		 ptr2[j-(1+degrees)]= 0;
		 //*direction = latitude[i];
		 *direction = gpllBuffer[i];
		 
		 return i;
}

void parsingGpsFunction (void *argument){	
	int i = 0 ;
  struct dataBase Latitude, Longitude;
	Latitude.id = LATITUDE;
	Longitude.id = LONGITUDE;
	while(1){
  if( xSemaphoreTake( gpsSemaphore, portMAX_DELAY ) == pdTRUE ){
		 i = fillGPS(degreeLatitude,minutosLatitude,1,2,&directionLatitude);
		 degreeLatitude[2] = '.';
		 fillGPS(degreeLongitude,minutosLongitude,(i + 2),3,&directionLongitude);

     //Longitude
		 dLongitude = atof (degreeLongitude);
		 mLongitude = atof (minutosLongitude);
		 coordinates.longitude = dLongitude + (mLongitude/60) ;
		 if(directionLongitude == 'W') coordinates.longitude = - coordinates.longitude ;
		
		//Latitude
		 dLatitute = (int) atof (degreeLatitude);
		 mLatitute = atof (minutosLatitude);
		 coordinates.latitude = dLatitute + (mLatitute/60) ;
		 if(directionLatitude == 'S')  coordinates.latitude = - coordinates.latitude;
		 Latitude.value = coordinates.latitude ;
		 Longitude.value = coordinates.longitude;	
		 if (xQueueSend(dataBaseQueue, &Latitude, portMAX_DELAY) != pdPASS) printf(" Latitude: Unsuccessfully sent the struct\r\n");
		 if (xQueueSend(dataBaseQueue, &Longitude, portMAX_DELAY) != pdPASS) printf(" Longitude: Unsuccessfully sent the struct\r\n");
}}}

//***************** Reinforcement Learning ************************
void controlPM2_5Function (void *argument){
	uint32_t TickDelay = pdMS_TO_TICKS(5000); //1 minuto
  while(1){
	 resumeDMATwo();
	 vTaskDelay(TickDelay);
	}}
void getPM2_5Function(void *argument){
	struct dataBase pm;
	unsigned char aux;
	int i = 0;
	pm.id = PM;
	while(1){
	
			if(ulTaskNotifyTake( pdTRUE, portMAX_DELAY )== pdTRUE ){
				
				if(i & 1){
				pauseDMATwo();
				while(uart_get_rxbufsizeTwo() >0){
					aux = uart_getcharTwo();
					pms_process(aux);}
				pms_parsing(&pms_Data);
				if( xSemaphoreTake( pmMutex, portMAX_DELAY ) == pdTRUE ){
						pm2_5 = pms_Data.gm3PM2_5_std;
						pm.value = (double) pm2_5;
						xSemaphoreGive( pmMutex );}
				if( xSemaphoreGive( pmSemaphore ) != pdTRUE ) printf("PM:error in give");
				if (xQueueSend(dataBaseQueue, &pm, portMAX_DELAY) != pdPASS) printf(" PM : Unsuccessfully sent the struct\r\n");}
				i++;}
	 //vTaskDelay(pdMS_TO_TICKS(100));
	}}
void reinforcementLearningTaskFunction(void *argument){ 
	struct dataBase motor;
	motor.id = MOTOR;
	while(1){
		if( xSemaphoreTake( pmSemaphore, portMAX_DELAY ) == pdTRUE ){
			if( xSemaphoreTake( pmMutex, portMAX_DELAY ) == pdTRUE ){
				rl.state = pm2_5;
				xSemaphoreGive( pmMutex );
				if(qTable[0][rl.state] > qTable[1][rl.state]){
					rl.action = 0;
					HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET);}
				else{ 
					rl.action = 1;
				  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);}
				motor.value = (double) rl.action;
				if (xQueueSend(dataBaseQueue, &motor, portMAX_DELAY) != pdPASS) printf(" RL : Unsuccessfully sent the struct\r\n");
		}}
}}

//*********************** SMOKE ***********************************

void getSmokeFunction(void *argument){
	struct dataBase smoke;
	smoke.id = SMOKE;
	while(1)
	{
			if(ulTaskNotifyTake( pdTRUE, portMAX_DELAY )== pdTRUE ){
				smoke.value = 1;
			  if (xQueueSend(dataBaseQueue, &smoke, portMAX_DELAY) != pdPASS) printf(" RL : Unsuccessfully sent the struct\r\n");
				
	}}
}