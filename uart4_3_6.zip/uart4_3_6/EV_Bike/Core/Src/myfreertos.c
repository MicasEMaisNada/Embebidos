#include "myfreertos.h"
#include "usart.h"
/**************** TASK HANDLERS *****************/
xTaskHandle Sender_um_Handler;
xTaskHandle Sender_dois_Handler;
xTaskHandle Receiver_Handler;

/**************** QUEUE HANDLER *****************/
xQueueHandle SimpleQueue;

void init_rtos(void){
	
	SimpleQueue = xQueueCreate(5, sizeof(int));
	if(SimpleQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}

	xTaskCreate(Send_um_Task,"Um_Send",128,NULL,3,&Sender_um_Handler);
	xTaskCreate(Send_dois_task,"Dois_Send",128,(void *) 111,2,&Sender_dois_Handler);
	xTaskCreate(Receiver_task,"Receive",128,NULL,1, &Receiver_Handler);
	
	
	vTaskStartScheduler();

}

void Send_um_Task (void *argument)
{
	uint8_t i;
	unsigned char j;
	uint32_t TickDelay = pdMS_TO_TICKS(5000);
	while (1)
	{
		//printf("Entrei na task um!\r\n");
		i=uart_get_rxbufsize();
    
//		char *str = "b \r\n";
//		HAL_UART_Transmit(&huart3, (uint8_t *)str, strlen (str), HAL_MAX_DELAY);
		if(i!=0)	{
			i= uart_getchar();
			if (xQueueSend(SimpleQueue, &i, portMAX_DELAY) == pdPASS)printf(" Successfully sent the number\r\n");
		
		}
		vTaskDelay(TickDelay);
	}
}

void Send_dois_task (void *argument)
{
	uint32_t TickDelay = pdMS_TO_TICKS(1000);
	while (1)
	{
		if (usart4_flag){
			usart4_flag=0;
			switch(bt){
		case '1':
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
		break;
		case '2':
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
		break;
		case '3':
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
		break;
		case '4':
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
		break;
		case '5':
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
		break;
		case '6':
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
		//HAL_UART_Transmit_IT(&huart6, &bt,1)
		break;
		default:
			break;	
	}
			uart_putcharFour('a'); //manda por bluetooth
			putchar(bt); //imprime pro terminal
}
		vTaskDelay(TickDelay);
	}
}


void Receiver_task (void *argument)
{
	int received=0;
	uint32_t TickDelay = pdMS_TO_TICKS(5000);//3segundos
	while (1)
	{ 
		
		printf("entrei receive\r\n");
		uart_putchar('b');
		if (xQueueReceive(SimpleQueue, &received, portMAX_DELAY) == pdTRUE)
		{
			received=(unsigned char)received;
			printf(" %c\r\n",received);
			uart_putchar (received);
		}
		else printf("receive sem dados\r\n");
			
		vTaskDelay(TickDelay);
	}
}
