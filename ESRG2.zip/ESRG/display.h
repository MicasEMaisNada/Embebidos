#ifndef DISPLAY_H
#define DISPLAY_H
#include <QObject>
#include <QString>
#include <QtNetwork>
#include <QtDebug>
#include <QJsonDocument>
#include <QJsonValue>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrlQuery>
struct carInformation {
    Q_GADGET
    QString pm2_5_;
    QString motor_;
    Q_PROPERTY(QString pm2_5 MEMBER pm2_5_)
    Q_PROPERTY(QString motor MEMBER motor_)
};

/*
struct carInfo{
    QString motor_;
    QString pm2_5_;
};Q_DECLARE_METATYPE(carInfo)*/

class Display : public QObject
{
    Q_OBJECT
    Q_PROPERTY(carInformation car READ getMyStruct
                NOTIFY refreshDisplay)
public:
    explicit Display(QObject *parent = nullptr);
    void get_info_database();
    carInformation getMyStruct();
    int pm2_5();
    QString motor();
signals:
   void refreshDisplay(carInformation* ms);
public slots:
    void replyFinished(QNetworkReply *);
    void readyRead();
    void requestError(QNetworkReply::NetworkError);
private:
    QNetworkAccessManager manager;
    carInformation *car_;
    QString msg;

};

#endif // DISPLAY_H
