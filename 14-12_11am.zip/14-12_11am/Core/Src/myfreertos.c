#include "myfreertos.h"

/***************** Macros  ********************/
#define head 0
#define byte1 1
#define byte2 2
#define carryReturn 3
#define erro 4
#define parsing 5
#define	ERRO_SIZE	16

/**************** TASK HANDLERS *****************/
xTaskHandle Sender_um_Handler;
xTaskHandle Sender_dois_Handler;
xTaskHandle Receiver_Handler;
xTaskHandle getLocationHandler;
xTaskHandle parsingGpsHandler;
xTaskHandle Receiver_Handler;
/**************** QUEUE HANDLER *****************/
xQueueHandle SimpleQueue;
xQueueHandle dataBaseQueue;

/***************** Variables  ********************/
struct dataBase{
		char id;
		int value;
};

struct command{
		char pid;
		char byte_1 ;
	  char byte_2 ;
};
struct car{
		char fuelType;
		char fuelLevel ;
	  char distanceTravelled ;
};
struct car car;
struct command command;
char commandErro[ERRO_SIZE];
int write=0;
int len = 1;

void init_rtos(void){
	
	SimpleQueue = xQueueCreate(5, sizeof(int));
	if(SimpleQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}
	
	dataBaseQueue=xQueueCreate(7, sizeof(struct dataBase));
	if(dataBaseQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}

	xTaskCreate(Send_um_Task,"Um_Send",128,NULL,3,&Sender_um_Handler);
  xTaskCreate(Send_dois_task,"Dois_Send",128,(void *) 111,2,&Sender_dois_Handler);
	xTaskCreate(Receiver_task,"Receive",128,NULL,1, &Receiver_Handler);
	xTaskCreate(getLocationFunction,"getLocation",128,NULL,1, &getLocationHandler);
	xTaskCreate(parsingGpsFunction,"parsingGps",128,NULL,1, &parsingGpsHandler);
	
	
	vTaskStartScheduler();

}

void Send_um_Task (void *argument)
{
	uint8_t i;
	unsigned char j;
	uint32_t TickDelay = pdMS_TO_TICKS(500);
	while (1)
	{
		//printf("Entrei na task um!\r\n");
		i=uart_get_rxbufsize();
    
//		char *str = "b \r\n";
//		HAL_UART_Transmit(&huart3, (uint8_t *)str, strlen (str), HAL_MAX_DELAY);
		if(i!=0)	{
			i= uart_getchar();
			if (xQueueSend(SimpleQueue, &i, portMAX_DELAY) != pdPASS)printf(" Unuccessfully sent the number\r\n");
		
		}
		vTaskDelay(TickDelay);
	}
}

void Send_dois_task (void *argument)
{
	char command;
	struct dataBase theReceiver;
	uint32_t TickDelay = pdMS_TO_TICKS(1000);
	while (1)
	{
		if (xQueueReceive(dataBaseQueue, &theReceiver, portMAX_DELAY) == pdTRUE)
		{
			command=(char)(theReceiver.value);
			uart_putchar (command);
			
		}
		//vTaskDelay(TickDelay);
	}
}


void Receiver_task (void *argument)
{
	char auxiliar = 0;
	int received = 0;
	char state, nextState = 0;
	struct dataBase aux;
	uint32_t TickDelay = pdMS_TO_TICKS(5000);//3segundos
	while (1)
	{ //printf("entrei receive\r\n");
		//uart_putchar('b');
		if (xQueueReceive(SimpleQueue, &received, portMAX_DELAY) == pdTRUE)
		{
			//received=(unsigned char)received;
			//printf(" %c\r\n",received);
			//uart_putchar (received);
//			auxiliar = (char)received;
//			state = nextState;
//			switch (state)
//			{
//				case head: 
//					if((auxiliar == 30) |(auxiliar == 32)| (auxiliar == 52)){
//						command.pid = auxiliar;
//						nextState = byte1;
//					}
//					else{
//						commandErro[write & (ERRO_SIZE -1)] = auxiliar;
//						write++;
//						nextState = erro;
//					}	
//				break;
//				case byte1:
//					command.byte_1 = auxiliar;
//				  nextState = (~(state+len))+2;
//				break;
//				case byte2:	
//					command.byte_2 = auxiliar;
//					nextState = carryReturn;
//				case carryReturn:
//					if(auxiliar == 0D){
//						nextState = parsing;
//					}
//					else {
//						nextState = erro;
//					}
//				case erro:	
//				case parsing:	
//				default:
//					
//			}
			aux.id = 1;
			aux.value = received;
			if (xQueueSend(dataBaseQueue, &aux, portMAX_DELAY) != pdPASS)
			{
				printf(" Unsuccessfully sent the struct\r\n");
			}
		}
		//else printf("receive sem dados\r\n");
			
		//vTaskDelay(TickDelay);
	}
}
void getLocationFunction (void *argument)
{
	
}

void parsingGpsFunction (void *argument)
{
	
}


