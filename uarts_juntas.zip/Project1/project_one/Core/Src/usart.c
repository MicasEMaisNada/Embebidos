/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */

Uart uart_2, uart_3, uart_4, uart_6, uart_7;


/* USER CODE END 0 */

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart7;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;
DMA_HandleTypeDef hdma_uart7_rx;

/* UART4 init function */
void MX_UART4_Init(void)
{

  huart4.Instance = UART4;
  huart4.Init.BaudRate = 9600;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }

}
/* UART7 init function */
void MX_UART7_Init(void)
{

  huart7.Instance = UART7;
  huart7.Init.BaudRate = 115200;
  huart7.Init.WordLength = UART_WORDLENGTH_8B;
  huart7.Init.StopBits = UART_STOPBITS_1;
  huart7.Init.Parity = UART_PARITY_NONE;
  huart7.Init.Mode = UART_MODE_TX_RX;
  huart7.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart7.Init.OverSampling = UART_OVERSAMPLING_16;
  huart7.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart7.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart7) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART2 init function */

void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART3 init function */

void MX_USART3_UART_Init(void)
{

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART6 init function */

void MX_USART6_UART_Init(void)
{

  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  huart6.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart6.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspInit 0 */

  /* USER CODE END UART4_MspInit 0 */
    /* UART4 clock enable */
    __HAL_RCC_UART4_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**UART4 GPIO Configuration
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART4;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* UART4 interrupt Init */
    HAL_NVIC_SetPriority(UART4_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspInit 1 */

  /* USER CODE END UART4_MspInit 1 */
  }
  else if(uartHandle->Instance==UART7)
  {
  /* USER CODE BEGIN UART7_MspInit 0 */

  /* USER CODE END UART7_MspInit 0 */
    /* UART7 clock enable */
    __HAL_RCC_UART7_CLK_ENABLE();

    __HAL_RCC_GPIOE_CLK_ENABLE();
    /**UART7 GPIO Configuration
    PE7     ------> UART7_RX
    PE8     ------> UART7_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART7;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    /* UART7 DMA Init */
    /* UART7_RX Init */
    hdma_uart7_rx.Instance = DMA1_Stream3;
    hdma_uart7_rx.Init.Channel = DMA_CHANNEL_5;
    hdma_uart7_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_uart7_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_uart7_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_uart7_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_uart7_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_uart7_rx.Init.Mode = DMA_NORMAL;
    hdma_uart7_rx.Init.Priority = DMA_PRIORITY_LOW;
    hdma_uart7_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_uart7_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_uart7_rx);

    /* UART7 interrupt Init */
    HAL_NVIC_SetPriority(UART7_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(UART7_IRQn);
  /* USER CODE BEGIN UART7_MspInit 1 */

  /* USER CODE END UART7_MspInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();

    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PD5     ------> USART2_TX
    PD6     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USART2 interrupt Init */
    HAL_NVIC_SetPriority(USART2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspInit 0 */

  /* USER CODE END USART3_MspInit 0 */
    /* USART3 clock enable */
    __HAL_RCC_USART3_CLK_ENABLE();

    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**USART3 GPIO Configuration
    PD8     ------> USART3_TX
    PD9     ------> USART3_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USART3 interrupt Init */
    HAL_NVIC_SetPriority(USART3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspInit 1 */

  /* USER CODE END USART3_MspInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspInit 0 */

  /* USER CODE END USART6_MspInit 0 */
    /* USART6 clock enable */
    __HAL_RCC_USART6_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_USART6;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART6 interrupt Init */
    HAL_NVIC_SetPriority(USART6_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspInit 1 */

  /* USER CODE END USART6_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspDeInit 0 */

  /* USER CODE END UART4_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_UART4_CLK_DISABLE();

    /**UART4 GPIO Configuration
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_10|GPIO_PIN_11);

    /* UART4 interrupt Deinit */
    HAL_NVIC_DisableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspDeInit 1 */

  /* USER CODE END UART4_MspDeInit 1 */
  }
  else if(uartHandle->Instance==UART7)
  {
  /* USER CODE BEGIN UART7_MspDeInit 0 */

  /* USER CODE END UART7_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_UART7_CLK_DISABLE();

    /**UART7 GPIO Configuration
    PE7     ------> UART7_RX
    PE8     ------> UART7_TX
    */
    HAL_GPIO_DeInit(GPIOE, GPIO_PIN_7|GPIO_PIN_8);

    /* UART7 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmarx);

    /* UART7 interrupt Deinit */
    HAL_NVIC_DisableIRQ(UART7_IRQn);
  /* USER CODE BEGIN UART7_MspDeInit 1 */

  /* USER CODE END UART7_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PD5     ------> USART2_TX
    PD6     ------> USART2_RX
    */
    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_5|GPIO_PIN_6);

    /* USART2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspDeInit 0 */

  /* USER CODE END USART3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART3_CLK_DISABLE();

    /**USART3 GPIO Configuration
    PD8     ------> USART3_TX
    PD9     ------> USART3_RX
    */
    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_8|GPIO_PIN_9);

    /* USART3 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspDeInit 1 */

  /* USER CODE END USART3_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspDeInit 0 */

  /* USER CODE END USART6_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART6_CLK_DISABLE();

    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6|GPIO_PIN_7);

    /* USART6 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspDeInit 1 */

  /* USER CODE END USART6_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */



void Uart_struct_init(void)
{
		uart_2.uart_nr=2;
		uart_2.TxWriteIndex=0;
		uart_2.TxReadIndex=0;
		uart_2.RxWriteIndex=0;
		uart_2.RxReadIndex=0;
		uart_2.ti_restart=1;
	
		uart_3.uart_nr=3;
		uart_3.TxWriteIndex=0;
		uart_3.TxReadIndex=0;
		uart_3.RxWriteIndex=0;
		uart_3.RxReadIndex=0;
		uart_3.ti_restart=1;
	
		uart_4.uart_nr=4;
		uart_4.TxWriteIndex=0;
		uart_4.TxReadIndex=0;
		uart_4.RxWriteIndex=0;
		uart_4.RxReadIndex=0;
		uart_4.ti_restart=1;
	
		uart_6.uart_nr=6;
		uart_6.TxWriteIndex=0;
		uart_6.TxReadIndex=0;
		uart_6.RxWriteIndex=0;
		uart_6.RxReadIndex=0;
		uart_6.ti_restart=1;
		
		uart_7.uart_nr=7;
		uart_7.TxWriteIndex=0;
		uart_7.TxReadIndex=0;
		uart_7.RxWriteIndex=0;
		uart_7.RxReadIndex=0;
		uart_7.ti_restart=1;
}


#pragma disable 
int uart_putchar (Uart *uart, unsigned char c)
{

		if(uart_get_txbufsize(uart) >= TBUF_SIZE) return (-ENOBUFS);
		uart->TxBuff [uart->TxWriteIndex & (TBUF_SIZE -1)]= c ;
		uart->TxWriteIndex++;
		if (uart->ti_restart)
		{ 
		uart->ti_restart=0;
			if(uart->uart_nr == 3)
			HAL_UART_Transmit_IT(&huart3,&(uart_3.TxBuff[uart_3.TxReadIndex & (TBUF_SIZE-1)]), 1);
			if(uart->uart_nr == 6)
			HAL_UART_Transmit_IT(&huart6,&(uart_6.TxBuff[uart_6.TxReadIndex & (TBUF_SIZE-1)]), 1);
			if(uart->uart_nr == 4)
			HAL_UART_Transmit_IT(&huart4,&(uart_4.TxBuff[uart_4.TxReadIndex & (TBUF_SIZE-1)]), 1);
			if(uart->uart_nr == 2)
			HAL_UART_Transmit_IT(&huart2,&(uart_2.TxBuff[uart_2.TxReadIndex & (TBUF_SIZE-1)]), 1);
			if(uart->uart_nr == 7)
			HAL_UART_Transmit_IT(&huart7,&(uart_7.TxBuff[uart_7.TxReadIndex & (TBUF_SIZE-1)]), 1);
		uart->TxReadIndex++;
		}
		return 0;
	}	



#pragma disable 
int uart_getchar(Uart *uart)
{
	if(uart_get_rxbufsize(uart)==0)  return (-ENODATA);
	return (uart->RxBuff[(uart->RxReadIndex++) & (RBUF_SIZE -1)]);
}

#pragma disable 
uint8_t uart_get_rxbufsize(Uart *uart)
{
	return ( uart->RxWriteIndex - uart->RxReadIndex);
}
#pragma disable 
uint8_t uart_get_txbufsize(Uart *uart)
{
	return ( uart->TxWriteIndex - uart->TxReadIndex);
}




//-----------------------------------------------------
void init_UARTS(){
	HAL_UART_Receive_IT(&huart3,&uart_3.RxBuff[uart_3.RxWriteIndex], 1);
	HAL_UART_Receive_IT(&huart2,&uart_2.RxBuff[uart_2.RxWriteIndex], 1);
	HAL_UART_Receive_IT(&huart6,&uart_6.RxBuff[uart_6.RxWriteIndex], 1); 
	//HAL_UART_Receive_IT(&huart4,&bt, 1); 
	HAL_UART_Receive_IT(&huart4,&uart_4.RxBuff[uart_4.RxWriteIndex], 1); 
	HAL_UART_Receive_IT(&huart7,&uart_7.RxBuff[uart_7.RxWriteIndex], 1); 
}





//implemantation of UART ISR
void HAL_UART_RxCpltCallback(UART_HandleTypeDef* huart){
	if (huart->Instance == USART3){ 
		uart_3.RxWriteIndex++ ;
		HAL_UART_Receive_IT(&huart3, &uart_3.RxBuff[uart_3.RxWriteIndex  & (RBUF_SIZE-1)], 1);
		//Flag or condition variable to warn the system that something was received, then go to the task and process that data
	}
	
	if (huart->Instance == USART6){ 
		uart_6.RxWriteIndex ++ ;
		HAL_UART_Receive_IT(&huart6, &uart_6.RxBuff[uart_6.RxWriteIndex  & (RBUF_SIZE-1)], 1);
		}
	if (huart->Instance == UART4){ 
		//HAL_UART_Receive_IT(&huart4, &bt, 1);
		//usart4_flag = 1;
		
		uart_4.RxWriteIndex ++ ;
		HAL_UART_Receive_IT(&huart4, &uart_4.RxBuff[uart_4.RxWriteIndex  & (RBUF_SIZE-1)], 1);
	}
	
	if (huart->Instance == USART2){
		uart_2.RxWriteIndex ++ ;		
		HAL_UART_Receive_IT(&huart2, &uart_2.RxBuff[uart_2.RxWriteIndex  & (RBUF_SIZE-1)], 1);
	}
	
	if (huart->Instance == UART7){
		uart_7.RxWriteIndex ++ ;		
		HAL_UART_Receive_IT(&huart7, &uart_7.RxBuff[uart_7.RxWriteIndex  & (RBUF_SIZE-1)], 1);
	}
}

void HAL_UART_TxCpltCallback (UART_HandleTypeDef *huart){

		if (huart->Instance == USART3){ 
		if(uart_get_txbufsize(&uart_3) !=0){
			uart_3.ti_restart=0;
			HAL_UART_Transmit_IT(&huart3,&(uart_3.TxBuff[uart_3.TxReadIndex & (TBUF_SIZE-1)]), 1);
			uart_3.TxReadIndex ++;
		}
		else 
			uart_3.ti_restart=1;
	}

		if (huart->Instance == UART4){ 
		if(uart_get_txbufsize(&uart_4) !=0){
			uart_4.ti_restart=0;
			HAL_UART_Transmit_IT(&huart4,&(uart_4.TxBuff[uart_4.TxReadIndex & (TBUF_SIZE-1)]), 1);
			uart_4.TxReadIndex ++;
		}
		else 
			uart_4.ti_restart=1;
	}

		if (huart->Instance == USART6){ 
		if(uart_get_txbufsize(&uart_6) !=0){
			uart_6.ti_restart=0;
			HAL_UART_Transmit_IT(&huart6,&(uart_6.TxBuff[uart_6.TxReadIndex & (TBUF_SIZE-1)]), 1);
			uart_6.TxReadIndex ++;
		}
		else 
			uart_6.ti_restart=1;
	}
		
	if (huart->Instance == USART2){ 
		if(uart_get_txbufsize(&uart_2) !=0){
			uart_2.ti_restart=0;
			HAL_UART_Transmit_IT(&huart2,&(uart_2.TxBuff[uart_2.TxReadIndex & (TBUF_SIZE-1)]), 1);
			uart_2.TxReadIndex ++;
		}
		else 
			uart_2.ti_restart=1;
	}
	
	if (huart->Instance == UART7){ 
		if(uart_get_txbufsize(&uart_7) !=0){
			uart_7.ti_restart=0;
			HAL_UART_Transmit_IT(&huart7,&(uart_7.TxBuff[uart_7.TxReadIndex & (TBUF_SIZE-1)]), 1);
			uart_7.TxReadIndex ++;
		}
		else 
			uart_7.ti_restart=1;
	}
}






//redifine the stdout
int fputc(int ch, FILE *f){
	HAL_UART_Transmit(&huart3, (uint8_t*)&ch, 1, 100);
	return ch;
}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
