#include "usart.h"
#include "string.h"


//AT
//Acknowledgement returns �OK�________________________________________________________________________________________________________________________
 void send_AT(){
	unsigned char at[4]= "AT\r\n";
	for(int i=0; i<4; i++) uart_putchar(&uart_6, at[i]);
}


//AT+RST
//RESTART_________________________________________________________________________________________________________________________________
void send_RST(){
	unsigned char at[8]= "AT+RST\r\n";
	for(int i=0; i<8; i++) uart_putchar(&uart_6, at[i]);
}

//AT+GMR
//FIRMWARE__________________________________________________________________________________________________________________________
void get_Firmware(){
	unsigned char at[8]= "AT+GMR\r\n";
	for(int i=0; i<8; i++) uart_putchar(&uart_6, at[i]);
}

//AT+CWMODE=nr
//Set Operation Mode__________________________________________________________________________________________________________________________________
void set_Mode(unsigned char nr){
	
	//nr=1 --> Station Mode
	//nr=2 -->

unsigned char at[13]="AT+CWMODE=";
at[10]=nr;
at[11]='\r';
at[12]='\n';

for(int i=0; i<13; i++) uart_putchar(&uart_6, at[i]);
}


//AT+CWLAP
//List the AP__________________________________________________________________________________________________________________________________
void Wifi_list() {
	unsigned char at[10]= "AT+CWLAP\r\n";
	for(int i=0; i<10; i++) uart_putchar(&uart_6, at[i]);
}

//AT+CWJAP=�SSID�,�PASSWORD�
//Joins AP___________________________________________________________________________________________________________________
void Wifi_Connect() {	
	unsigned char at[36]= "AT+CWJAP=\"MEO-3936A0\",\"d025807f44\"\r\n";
	for(int i=0; i<36; i++) uart_putchar(&uart_6, at[i]);
}


//AT+CWQAP
//Quits AP______________________________________________________________________________________________________________________________________

void Wifi_Disconnect() {
	unsigned char at[10]= "AT+CWQAP\r\n";
	for(int i=0; i<10; i++) uart_putchar(&uart_6, at[i]);
}

//AT+CIFSR
//IP address______________________________________________________________________________________________________________________________

void GetIp(){
	unsigned char at[10]= "AT+CIFSR\r\n";
	for(int i=0; i<10; i++) uart_putchar(&uart_6, at[i]);

}




//*********************** MQTT *************************

//AT+MQTTUSERCFG=<LinkID>,<scheme>,<"client_id">,<"username">,<"password">,<cert_key_ID>,<CA_ID>,<"path">


//AT+MQTTCLIENTID=<LinkID>,<"client_id">
//Client ID______________________________________________________________________________________________________

void set_ClientID(){
	unsigned char at[112]= "AT+MQTTCLIENTID=\"projects/spring-forest-298515/locations/us-central1/registries/my-registry/devices/my-device\"\r\n";
	for(int i=0; i<112; i++) uart_putchar(&uart_6, at[i]);
}


void set_ClientUsername(){
	unsigned char at[24]= "AT+MQTTUSERNAME=0,mqtt\r\n";
	for(int i=0; i<24; i++) uart_putchar(&uart_6, at[i]);
}

void set_ClientPassword(){
	unsigned char at[24]= "AT+MQTTPASSWORD=0,1234\r\n";
	for(int i=0; i<24; i++) uart_putchar(&uart_6, at[i]);
}

void connect(){
	unsigned char at[44]= "AT+MQTTCONN=0,\"mqtt.googleapis.com\",443,0\r\n";
	for(int i=0; i<44; i++) uart_putchar(&uart_6, at[i]);
}

