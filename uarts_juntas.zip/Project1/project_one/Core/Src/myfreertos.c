#include "myfreertos.h"
#include "usart.h"
#include "esp8266.h"
/**************** TASK HANDLERS *****************/
xTaskHandle Sender_dois_Handler;
xTaskHandle Receiver_Handler;
/**************** QUEUE HANDLER *****************/
xQueueHandle SimpleQueue;

void init_rtos(void){
	
	SimpleQueue = xQueueCreate(5, sizeof(int));
	if(SimpleQueue ==0){
		printf("Unable to create queue\r\n");
	}
	else{
		printf("Queue Created\r\n");
	}
	xTaskCreate(Send_dois_task,"Dois_Send",128,(void *) 111,2,&Sender_dois_Handler);
	xTaskCreate(Receiver_task,"Receive",128,NULL,1, &Receiver_Handler);
	vTaskStartScheduler();
}

void Send_dois_task (void *argument)
{
	uint32_t TickDelay = pdMS_TO_TICKS(1000);
	while (1)
	{
//		if (usart4_flag){
//			usart4_flag=0;
//			switch(bt){
//		case '1':
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
//		break;
//		case '2':
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
//		break;
//		case '3':
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
//		break;
//		case '4':
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
//		break;
//		case '5':
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
//		break;
//		case '6':
//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
//		//HAL_UART_Transmit_IT(&huart6, &bt,1)
//		break;
//		default:
//			break;	
//	}
//			uart_putcharFour('a'); //manda por bluetooth
//			putchar(bt); //imprime pro terminal
//}
		vTaskDelay(TickDelay);
	}
}


void Receiver_task (void *argument)
{
	uint32_t TickDelay = pdMS_TO_TICKS(200);
	while (1)
	{ 
		
		if(uart_get_rxbufsize(&uart_6) >0)
				printf("%c", uart_getchar(&uart_6));
		
		
		
		if(uart_get_rxbufsize(&uart_3)>0)
		if(uart_get_rxbufsize(&uart_3)>0)
			switch(uart_getchar(&uart_3)){
			case '1':{
				//printf("AT sent");
				send_AT();
				break;
				}
			case '2':{
				//printf("RST sent");
				send_RST();
				break;
			}
			case '3':{
				set_Mode('1');
				break;
			}
			case '4':{
				Wifi_list();
				break;
			}
			case '5':{
				Wifi_Connect();
				break;
			}
			case '6':{
				set_ClientID();
				break;
			}
			
			case '7':{
				//printf("ola");
				uart_putchar(&uart_3, 'a');
				break;
			}
			default:
				break;
		}
			
		vTaskDelay(TickDelay);
	}
}
