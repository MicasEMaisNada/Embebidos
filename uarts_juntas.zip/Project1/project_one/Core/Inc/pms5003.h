#include <stdint.h>

typedef struct {
    uint16_t gm3PM1_0_std;
    uint16_t gm3PM2_5_std;
    uint16_t gm3PM10_0_std;
    uint16_t gm3PM1_0_env;
    uint16_t gm3PM2_5_env;
    uint16_t gm3PM10_0_env;
    uint16_t nrGt0_3um;
    uint16_t nrGt0_5um;
    uint16_t nrGt1_0um;
    uint16_t nrGt2_5um;
    uint16_t nrGt5_0um;
    uint16_t nrGt10_0um;
    uint8_t version;
    uint8_t errorCode;
} pms_data;

void pms_init(void);
uint8_t pms_process(uint8_t byte);
void pms_parsing(pms_data *data);