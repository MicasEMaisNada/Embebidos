#ifndef __myfreertos_H__
#define __myfreertos_H__

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "usart.h"

#include "string.h"
#include "stdio.h"

///**************** TASK HANDLERS *****************/
//xTaskHandle Sender_um_Handler;
//xTaskHandle Sender_dois_Handler;
//xTaskHandle Receiver_Handler;

///**************** QUEUE HANDLER *****************/
//xQueueHandle SimpleQueue;

void Send_um_Task(void *argument);
void Send_dois_task(void *argument);
void Receiver_task(void *argument);

void init_rtos(void);

#endif /*__ myfreertos_H_ */
