#ifndef MAINACTIVITY_H
#define MAINACTIVITY_H
#include <QObject>
#include <QString>
#include <QtDebug>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <mqueue.h>
#include <stdlib.h>
#include <signal.h>
#include "display.h"
using namespace std;
#define MSGQOBJ_NAME    "/myqueue123"
#define MAX_MSG_LEN     10000

class MainActivity : public QObject
{
    Q_OBJECT
public:
    MainActivity(QObject* parent = 0);
    void create_pthreads();
    void wait_pthreads();
    static void timer_handler(int signo);
    void display_updtade_function();
    void display_refresh_function();
    pthread_t display_up_id,display_re_id,get_mes_id;
    pthread_attr_t display_up_attr,display_re_attr,get_mes_attr;
    sched_param display_up_thread,display_re_thread,get_mes_thread;
    pthread_mutex_t timer_up_ConditionMutex = PTHREAD_MUTEX_INITIALIZER,timer_re_ConditionMutex = PTHREAD_MUTEX_INITIALIZER,timer_getmess_ConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t timer_up_Condition = PTHREAD_COND_INITIALIZER,timer_re_Condition = PTHREAD_COND_INITIALIZER,timer_getmess_Condition = PTHREAD_COND_INITIALIZER;
    mqd_t msgq_id;
    char msgcontent[MAX_MSG_LEN];
    int msgsz;
    unsigned int sender;
    struct mq_attr msgq_attr;
signals:
    void refreshDisplay(QString mm, QString mp);
    void display_updtade_signal();
private:
    Display *display;
    static void *display_updtade_thread(void *);
    static void *display_refresh_thread(void *);
    static void *get_message_thread(void *);
    int i=0;
};
extern MainActivity act;
#endif // MAINACTIVITY_H
