#include "mainactivity.h"
MainActivity act;
MainActivity::MainActivity(QObject*parent): QObject(parent)
{
    display = new Display();
    connect(this,&MainActivity::display_updtade_signal,display,&Display::get_info_database);
    this->create_pthreads();
}

void MainActivity::create_pthreads()
{
      qDebug()<<"inside the thread cretor";
      display_up_thread.sched_priority = 1;
      pthread_attr_setdetachstate(&display_up_attr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&display_up_attr,&display_up_thread);
      pthread_attr_init(&display_up_attr);
      if(pthread_create(&display_up_id, &display_up_attr, display_updtade_thread, this)) qDebug()<<"error creating thread";
      display_up_thread.sched_priority = 1;
      pthread_attr_setdetachstate(&display_re_attr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&display_re_attr,&display_re_thread);
      pthread_attr_init(&display_re_attr);
      if(pthread_create(&display_re_id, &display_re_attr, display_refresh_thread, this)) qDebug()<<"error creating thread";
      get_mes_thread.sched_priority = 1;
      pthread_attr_setdetachstate(&get_mes_attr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&get_mes_attr,&get_mes_thread);
      pthread_attr_init(&get_mes_attr);
      if(pthread_create(&get_mes_id, &get_mes_attr, get_message_thread, this)) qDebug()<<"error creating thread";
}

void MainActivity::wait_pthreads()
{
    pthread_join(display_up_id,nullptr);
    pthread_join(display_re_id,nullptr);
}

void MainActivity::timer_handler(int signo)
{
    if(signo == SIGALRM ){
        qDebug()<<"Timer overflow";
        if(act.i==1){
            pthread_mutex_lock(&act.timer_up_ConditionMutex);
            pthread_cond_signal(&act.timer_up_Condition);
            pthread_mutex_unlock(&act.timer_up_ConditionMutex);}
        if(act.i==2){
            pthread_mutex_lock(&act.timer_re_ConditionMutex);
            pthread_cond_signal(&act.timer_re_Condition);
            pthread_mutex_unlock(&act.timer_re_ConditionMutex);}
        if(act.i==3){
            pthread_mutex_lock(&act.timer_getmess_ConditionMutex);
            pthread_cond_signal(&act.timer_getmess_Condition);
            pthread_mutex_unlock(&act.timer_getmess_ConditionMutex);
            act.i = 0;}

      act.i++;
    }

}

void MainActivity::display_updtade_function()
{
    emit display_updtade_signal();
}

void MainActivity::display_refresh_function()
{
    emit refreshDisplay(display->getMotor(),display->getPm());
}

void *MainActivity::display_updtade_thread(void *)
{
    while(1){
        pthread_mutex_lock(&act.timer_up_ConditionMutex);
        pthread_cond_wait(&act.timer_up_Condition,&act.timer_up_ConditionMutex);
        pthread_mutex_unlock(&act.timer_up_ConditionMutex);
        qDebug()<<"display update";
        act.display_updtade_function();
    }}

void *MainActivity::display_refresh_thread(void *)
{
    while(1){
        pthread_mutex_lock(&act.timer_re_ConditionMutex);
        pthread_cond_wait(&act.timer_re_Condition,&act.timer_re_ConditionMutex);
        pthread_mutex_unlock(&act.timer_re_ConditionMutex);
        qDebug()<<"display refresh";
        act.display_refresh_function();
    }
}

void *MainActivity::get_message_thread(void *)
{
    act.msgq_id = mq_open(MSGQOBJ_NAME, O_RDWR);
    if (act.msgq_id == (mqd_t)-1) perror("In mq_open()");
    while(1){
        pthread_mutex_lock(&act.timer_getmess_ConditionMutex);
        pthread_cond_wait(&act.timer_getmess_Condition,&act.timer_getmess_ConditionMutex);
        pthread_mutex_unlock(&act.timer_getmess_ConditionMutex);
        qDebug()<<"get_message";
        act.msgsz = mq_receive(act.msgq_id, act.msgcontent, MAX_MSG_LEN, &act.sender);
            if (act.msgsz == -1)  perror("In mq_receive()");
            else {
                qDebug()<<"message received"<<act.msgcontent;
                //if (mq_unlink(MSGQOBJ_NAME) == -1)
                // perror("Removing queue error");
}}}
