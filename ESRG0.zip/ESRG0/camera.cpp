#include "camera.h"

Camera::Camera()
{

}
void Camera::configuration()
{
      m_camera.set(CV_CAP_PROP_FRAME_WIDTH, 640);
      m_camera.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
      m_camera.set(CV_CAP_PROP_BRIGHTNESS, 100);
      m_camera.set(CV_CAP_PROP_EXPOSURE, 100);
      m_camera.set(CV_CAP_PROP_CONTRAST, 100);
      m_camera.set(CV_CAP_PROP_SATURATION, 100);
}
bool Camera::takePicture()
{   int aux=0;
    int i=0 ;
    qDebug()<<"estou no takePiture";
    configuration();
    m_camera.release();
    if(!m_camera.isOpened())
        m_camera.open(0);
    if(m_camera.isOpened()) {
        while(i!=20){
            m_camera.read(picture);
            i++;}
        if(m_camera.read(picture)){
            qDebug()<< "tirou foto";
            imwrite("camera.jpg", picture);
            aux = 1;}
         else cout << "ERROR Capturing Frame!" << endl;
         m_camera.release();}
     else cout << "ERROR Opening Camera!" << endl;
    qDebug()<<"sai do takePiture";
    if(aux) return true;
    else return false;

}


