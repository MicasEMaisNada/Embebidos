#include "camera.h"

Camera::Camera()
{

}
void Camera::configuration()
{
      m_camera.set(CV_CAP_PROP_FRAME_WIDTH, 640);
      m_camera.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
      m_camera.set(CV_CAP_PROP_BRIGHTNESS, 100);
      m_camera.set(CV_CAP_PROP_EXPOSURE, 100);
      m_camera.set(CV_CAP_PROP_CONTRAST, 100);
      m_camera.set(CV_CAP_PROP_SATURATION, 100);
}
void Camera::takePicture()
{
    qDebug()<<"estou no takePiture";
    configuration();
         m_camera.release();
         if(!m_camera.isOpened())
               m_camera.open(0);

        if(m_camera.isOpened()) {
            if(m_camera.read(picture)){
                qDebug()<< "tirou foto";
                imwrite("camera.jpg", picture);
             }
            else cout << "ERROR Capturing Frame!" << endl;

            m_camera.release();}
        else cout << "ERROR Opening Camera!" << endl;
        qDebug()<<"sai do takePiture";
}


