#ifndef CAMERA_H
#define CAMERA_H

#include <QObject>
#include <QDebug>
#include <opencv2/opencv.hpp>
#include <opencv2/video.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
using namespace cv;
using namespace std;

class Camera: public QObject
{
    Q_OBJECT
public:
    Camera();
    bool takePicture();
private:
    VideoCapture m_camera;
    Mat picture;
    void configuration();
};

#endif // CAMERA_H
