#ifndef DISPLAY_H
#define DISPLAY_H
#include <QObject>
#include <QString>
#include <QtNetwork>
#include <QtDebug>
#include <QJsonDocument>
#include <QJsonValue>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrlQuery>
#include <QMetaType>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
/*
struct carInformation {
    Q_GADGET
    Q_PROPERTY(QString pm2_5 MEMBER pm2_5_)
    Q_PROPERTY(QString motor MEMBER motor_)
public:
    QString pm2_5_;
    QString motor_;

};Q_DECLARE_METATYPE(carInformation)*/

/*
struct carInfo{
    QString motor_;
    QString pm2_5_;
};Q_DECLARE_METATYPE(carInfo)*/

class Display : public QObject
{
    Q_OBJECT

public:
    explicit Display(QObject *parent = nullptr);
    QString getPm();
    QString getMotor();

public slots:
    void get_info_database();
    void postDatabase(int);
    void replyFinished(QNetworkReply *);
private:
    QNetworkAccessManager* manager;
    int pm2_5;
    int motor;

};

#endif // DISPLAY_H
