#ifndef DISPLAY_H
#define DISPLAY_H
#include <QObject>
#include <QString>
#include <QtNetwork>
#include <QtDebug>
#include <QJsonDocument>
#include <QJsonValue>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrlQuery>
#include <QMetaType>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>

class Communication : public QObject
{
    Q_OBJECT

public:
    explicit Communication(QObject *parent = nullptr);
    QString getPm();
    QString getMotor();

public slots:
    void get_info_database();
    void postDatabase(int);
    void replyFinished(QNetworkReply *);
private:
    QNetworkAccessManager* manager;
    int pm2_5;
    int motor;

};

#endif // DISPLAY_H
