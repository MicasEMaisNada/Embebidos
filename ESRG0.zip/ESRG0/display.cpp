#include "display.h"
using namespace std;
Display::Display(QObject *parent):QObject(parent)
{
    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));
    qDebug() << "updated successfully";
}

void Display::get_info_database()
{
    qDebug() << "in get_info_database";
    manager->get(QNetworkRequest(QUrl("http://api.thingspeak.com/channels/1280253/feeds.json?api_key=BDJ0QE8EP5FWXBIR&results=2")));
}
void Display::postDatabase(int value)
{
    QVariantMap feed;
    QString WRKey = "93FSUE68PNHIKDJT";
    feed.insert("api_key",WRKey);
    feed.insert("field8",QVariant(value).toString());
    QByteArray payload=QJsonDocument::fromVariant(feed).toJson();
    QUrl myurl;
    myurl.setScheme("http"); //https also applicable
    myurl.setHost("api.thingspeak.com");
    myurl.setPath("/update.json");
    QNetworkRequest request;
    request.setUrl(myurl);
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    QNetworkAccessManager *restclient; //in class
    restclient = new QNetworkAccessManager(this); //constructor
    QNetworkReply *reply = restclient->post(request,payload);

}
QString Display::getPm()
{
    if(pm2_5 < 50) return "Healthy";
    else if(pm2_5 <100)return "Moderate";
    else return "Unhealthy";
}

QString Display::getMotor()
{
    if(motor) return "On";
    else return "Off";
}

void Display::replyFinished(QNetworkReply *reply)
{
    qDebug() << "in reply";
    qDebug() << "readyRead:"<<reply;
    if(reply) {
        QByteArray data = reply->readAll();
        qDebug() << "Response:" << data;
        QJsonDocument jsonDoc = QJsonDocument::fromJson(data);
        QJsonObject root = jsonDoc.object();
        QJsonArray dataObject = root.value("feeds").toArray();
        QJsonValue  value = dataObject.at(1);
        pm2_5 = value["field4"].toInt();
        qDebug() << "PM2.5 :" <<pm2_5;

        motor = value["field5"].toInt();
        qDebug() << "Motor:" <<motor;
    }

   else qDebug() << "Error reading!";
}



