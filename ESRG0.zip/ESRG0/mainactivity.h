#ifndef MAINACTIVITY_H
#define MAINACTIVITY_H
#include <QObject>
#include <QString>
#include <QtDebug>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <mqueue.h>
#include <stdlib.h>
#include <signal.h>
#include "display.h"
#include "camera.h"
#include "facerecognition.h"
#include <sys/types.h>
using namespace std;
#define MAX_MSG_LEN     10000
#define LENGTH 50
#define MSG_Q_NAME "/MY_MSGQ_3"
class MainActivity : public QObject
{
    Q_OBJECT
public:
    MainActivity(QObject* parent = 0);
    void create_pthreads();
    void wait_pthreads();
    static void timer_handler(int signo);
    static void  tfunc(union sigval sv);
    void display_updtade_function();
    void display_refresh_function();
    void postDatabaseCall(int);
    pthread_t display_up_id,display_re_id,cameraID,faceID, trainID;
    pthread_attr_t display_up_attr,display_re_attr,cameraAttr,faceAttr,trainAttr;
    sched_param display_up_thread,display_re_thread,cameraThrea,faceThread,trainThrea;
    pthread_mutex_t timer_up_ConditionMutex = PTHREAD_MUTEX_INITIALIZER,timer_re_ConditionMutex = PTHREAD_MUTEX_INITIALIZER,timerTrainConditionMutex = PTHREAD_MUTEX_INITIALIZER,takePhotoConditionMutex = PTHREAD_MUTEX_INITIALIZER,photoAvailableConditionMutex = PTHREAD_MUTEX_INITIALIZER,trainDoneConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t timer_up_Condition = PTHREAD_COND_INITIALIZER,timer_re_Condition = PTHREAD_COND_INITIALIZER,timerTrainCondition = PTHREAD_COND_INITIALIZER,takePhotoCondition = PTHREAD_COND_INITIALIZER,photoAvailableCondition = PTHREAD_COND_INITIALIZER,trainDoneCondition = PTHREAD_COND_INITIALIZER;
    mqd_t msgq_id;
    char msgcontent[MAX_MSG_LEN];
    int msgsz;
    unsigned int sender;
    struct mq_attr msgq_attr;
signals:
    void refreshDisplay(QString mm, QString mp);
    void display_updtade_signal();
    void post(int);
private:
    Display *display;
    Camera  *camera;
    FaceRecognition *face;
    static void *display_updtade_thread(void *);
    static void *display_refresh_thread(void *);
    static void *cameraThread(void *);
    static void *faceDetectionThread(void *);
    static void *trainThread(void*);
    int i=0;
    int trainOver = 0;
};
extern MainActivity act;
#endif // MAINACTIVITY_H
