#ifndef MAINACTIVITY_H
#define MAINACTIVITY_H
#include <QObject>
#include <QString>
#include <QtDebug>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <mqueue.h>
#include <stdlib.h>
#include <signal.h>
#include "display.h"
#include "camera.h"
#include "facerecognition.h"
#include <fcntl.h>
using namespace std;
#define MAX_MSG_LEN     10000
#define LENGTH 50
#define MSG_Q_NAME "/MY_MSGQ_3"
class MainActivity : public QObject
{
    Q_OBJECT
public:
    MainActivity(QObject* parent = 0);
    void create_pthreads();
    void wait_pthreads();
    static void timerHandler(int signo);
    static void  msqNotifyHandler(union sigval sv);
    /* PThreads Parameters*/
    pthread_t displayUpId,displayReId,cameraID,faceID, trainID;
    pthread_attr_t displayUpAttr,displayReAttr,cameraAttr,faceAttr,trainAttr;
    sched_param displayUpThread,displayReThread,cameraThrea,faceThread,trainThrea;
    /* Mutexs */
    pthread_mutex_t timerUpConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t timerReConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t timerTrainConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t takePhotoConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t photoAvailableConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_t trainDoneConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    /* Condition Variables */
    pthread_cond_t timerUpCondition = PTHREAD_COND_INITIALIZER;
    pthread_cond_t timerReCondition = PTHREAD_COND_INITIALIZER;
    pthread_cond_t timerTrainCondition = PTHREAD_COND_INITIALIZER;
    pthread_cond_t takePhotoCondition = PTHREAD_COND_INITIALIZER;
    pthread_cond_t photoAvailableCondition = PTHREAD_COND_INITIALIZER;
    pthread_cond_t trainDoneCondition = PTHREAD_COND_INITIALIZER;
    /* Messague Queue */
    mqd_t msgq_id;
    char msgcontent[MAX_MSG_LEN];
    int msgsz;
    unsigned int sender;
    struct mq_attr msgq_attr;
signals:
    void refreshDisplay(QString mm, QString mp);
    void get();
    void post(int);
private:
    Communication *communication;
    Camera  *camera;
    FaceRecognition *face;
    /* Threads */
    static void *displayUpdtadeThread(void *);
    static void *displayRefreshThread(void *);
    static void *cameraThread(void *);
    static void *faceDetectionThread(void *);
    static void *trainThread(void*);
    /* Auxiliar Function */
    void displayUpdtadeFunction();
    void displayRefreshFunction();
    void postDatabaseCall(int);
    /* Variables */
    int i=0;
    int trainOver = 0;
};
extern MainActivity act;
#endif // MAINACTIVITY_H
