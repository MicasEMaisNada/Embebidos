#ifndef MAINACTIVITY_H
#define MAINACTIVITY_H
#include <QObject>
#include <QString>
#include <QtDebug>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <mqueue.h>
#include <stdlib.h>
#include <signal.h>
#include "display.h"
#include "camera.h"
#include "facerecognition.h"
#include <sys/types.h>
using namespace std;
#define MAX_MSG_LEN     10000
#define LENGTH 50
#define MSG_Q_NAME "/MY_MSGQ_3"
class MainActivity : public QObject
{
    Q_OBJECT
public:
    MainActivity(QObject* parent = 0);
    void create_pthreads();
    void wait_pthreads();
    static void timer_handler(int signo);
    static void  tfunc(union sigval sv);
    void display_updtade_function();
    void display_refresh_function();
    pthread_t display_up_id,display_re_id,cameraID,faceID;
    pthread_attr_t display_up_attr,display_re_attr,cameraAttr,faceAttr;
    sched_param display_up_thread,display_re_thread,cameraThrea,faceThread;
    pthread_mutex_t timer_up_ConditionMutex = PTHREAD_MUTEX_INITIALIZER,timer_re_ConditionMutex = PTHREAD_MUTEX_INITIALIZER,takePhotoConditionMutex = PTHREAD_MUTEX_INITIALIZER,photoAvailableConditionMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t timer_up_Condition = PTHREAD_COND_INITIALIZER,timer_re_Condition = PTHREAD_COND_INITIALIZER,takePhotoCondition = PTHREAD_COND_INITIALIZER,photoAvailableCondition = PTHREAD_COND_INITIALIZER;
    mqd_t msgq_id;
    char msgcontent[MAX_MSG_LEN];
    int msgsz;
    unsigned int sender;
    struct mq_attr msgq_attr;
signals:
    void refreshDisplay(QString mm, QString mp);
    void display_updtade_signal();
private:
    Display *display;
    Camera  *camera;
    FaceRecognition *face;
    static void *display_updtade_thread(void *);
    static void *display_refresh_thread(void *);
    static void *cameraThread(void *);
    static void *faceDetectionThread(void *);
    int i=0;
    static pid_t daemonPid;
    union sigval value;
    void sendSignal(int);
};
extern MainActivity act;
#endif // MAINACTIVITY_H
