#include "mainactivity.h"
MainActivity act;
MainActivity::MainActivity(QObject*parent): QObject(parent)
{
    display = new Display();
    camera = new Camera();
    face = new FaceRecognition();
    connect(this,&MainActivity::display_updtade_signal,display,&Display::get_info_database);
    this->create_pthreads();
}

void MainActivity::create_pthreads()
{
      qDebug()<<"inside the thread cretor";
      display_up_thread.sched_priority = 1;
      pthread_attr_setdetachstate(&display_up_attr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&display_up_attr,&display_up_thread);
      pthread_attr_init(&display_up_attr);
      if(pthread_create(&display_up_id, &display_up_attr, display_updtade_thread, this)) qDebug()<<"error creating thread";
      display_up_thread.sched_priority = 1;
      pthread_attr_setdetachstate(&display_re_attr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&display_re_attr,&display_re_thread);
      pthread_attr_init(&display_re_attr);
      if(pthread_create(&display_re_id, &display_re_attr, display_refresh_thread, this)) qDebug()<<"error creating thread";
      cameraThrea.sched_priority = 1;
      pthread_attr_setdetachstate(&cameraAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&cameraAttr,&cameraThrea);
      pthread_attr_init(&cameraAttr);
      if(pthread_create(&cameraID, &cameraAttr, cameraThread, this)) qDebug()<<"error creating thread";
      faceThread.sched_priority = 1;
      pthread_attr_setdetachstate(&faceAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&faceAttr,&faceThread);
      pthread_attr_init(&faceAttr);
      if(pthread_create(&faceID, &faceAttr, faceDetectionThread, this)) qDebug()<<"error creating thread";

}

void MainActivity::wait_pthreads()
{
    pthread_join(display_up_id,nullptr);
    pthread_join(display_re_id,nullptr);
}

void MainActivity::timer_handler(int signo)
{
    if(signo == SIGALRM ){
        qDebug()<<"Timer overflow";
        if(act.i==1){
            pthread_mutex_lock(&act.timer_up_ConditionMutex);
            pthread_cond_signal(&act.timer_up_Condition);
            pthread_mutex_unlock(&act.timer_up_ConditionMutex);}
        if(act.i==2){
            pthread_mutex_lock(&act.timer_re_ConditionMutex);
            pthread_cond_signal(&act.timer_re_Condition);
            pthread_mutex_unlock(&act.timer_re_ConditionMutex);
            act.i = 0;}
      act.i++;
    }

}

void MainActivity::display_updtade_function()
{
    emit display_updtade_signal();
}

void MainActivity::display_refresh_function()
{
    emit refreshDisplay(display->getMotor(),display->getPm());
}



void *MainActivity::display_updtade_thread(void *)
{
    while(1){
        pthread_mutex_lock(&act.timer_up_ConditionMutex);
        pthread_cond_wait(&act.timer_up_Condition,&act.timer_up_ConditionMutex);
        pthread_mutex_unlock(&act.timer_up_ConditionMutex);
        qDebug()<<"display update";
        act.display_updtade_function();
    }}

void *MainActivity::display_refresh_thread(void *)
{
    while(1){
        pthread_mutex_lock(&act.timer_re_ConditionMutex);
        pthread_cond_wait(&act.timer_re_Condition,&act.timer_re_ConditionMutex);
        pthread_mutex_unlock(&act.timer_re_ConditionMutex);
        qDebug()<<"display refresh";
        act.display_refresh_function();
}}

void *MainActivity::cameraThread(void *)
{
    while(1){
        pthread_mutex_lock(&act.takePhotoConditionMutex);
        pthread_cond_wait(&act.takePhotoCondition,&act.takePhotoConditionMutex);
        pthread_mutex_unlock(&act.takePhotoConditionMutex);
        qDebug()<<"cameraThread";
        if(act.camera->takePicture()){
            pthread_mutex_lock(&act.photoAvailableConditionMutex);
            pthread_cond_signal(&act.photoAvailableCondition);
            pthread_mutex_unlock(&act.photoAvailableConditionMutex);
        }
        //act.cameraThreadFunction();
}}

void *MainActivity::faceDetectionThread(void *)
{
    while(1){
        pthread_mutex_lock(&act.photoAvailableConditionMutex);
        pthread_cond_wait(&act.photoAvailableCondition,&act.photoAvailableConditionMutex);
        pthread_mutex_unlock(&act.photoAvailableConditionMutex);
        qDebug()<<"faceThread";
        act.face->recognizer();
        if(act.face->getConfidence()< 25){
            qDebug() << "foi reconhecida";
            int fd0 = open("/dev/led0",O_WRONLY);
            char on='1';
            write(fd0,&on,1);
            close(fd0);
        }
        else
           qDebug() << "não foi reconhecida";

 }}


 void  MainActivity::tfunc(union sigval sv)
{
  mqd_t msq_id = *(static_cast<mqd_t*>(sv.sival_ptr));

  struct mq_attr attr;
  if(mq_getattr(msq_id, &attr) < 0)
  {
    qDebug() << "Error in mq_getattr " << strerror(errno)  << endl;
    return;
  }

  // Reregister for new messages on Q
  struct sigevent sev;
  sev.sigev_notify = SIGEV_THREAD;
  sev.sigev_notify_function = act.tfunc;
  sev.sigev_notify_attributes = NULL;
  sev.sigev_value.sival_ptr = sv.sival_ptr;
  if (mq_notify(msq_id, &sev) < 0)
  {
    qDebug() << "Error during Reregister in msq_notify : "
         << strerror(errno) << endl;
    exit(EXIT_FAILURE);
  }

  // Read new message on the Q
  char* arr = new char[attr.mq_msgsize];
  memset(arr, 0, attr.mq_msgsize);
  if(mq_receive(msq_id, arr, attr.mq_msgsize, 0) < 0)
  {
    if(errno != EAGAIN)
    {
      qDebug() << "Error in mq_receive " << strerror(errno) << endl;
      exit(EXIT_FAILURE);
    }
  }
  else
  {
    qDebug() << "Msg rcvd " << arr << "n"<<atoi(arr)<< endl;
    if(atoi(arr) == 1){
        pthread_mutex_lock(&act.takePhotoConditionMutex);
        pthread_cond_signal(&act.takePhotoCondition);
        pthread_mutex_unlock(&act.takePhotoConditionMutex);
    }
    if(atoi(arr) == 2){
        int fd0 = open("/dev/led0",O_WRONLY);
        char off='0';
        write(fd0,&off,1);
        close(fd0);
    }
  }
}
