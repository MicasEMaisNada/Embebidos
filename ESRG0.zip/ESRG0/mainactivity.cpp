#include "mainactivity.h"
MainActivity act;

MainActivity::MainActivity(QObject*parent): QObject(parent)
{
    communication = new Communication();
    camera = new Camera();
    face = new FaceRecognition();
    connect(this,&MainActivity::get,communication,&Communication::get_info_database);
    connect(this,&MainActivity::post,communication,&Communication::postDatabase);
    this->create_pthreads();
}

void MainActivity::create_pthreads()
{
      qDebug()<<"inside the thread cretor";
      displayUpThread.sched_priority = 1;
      pthread_attr_setdetachstate(&displayUpAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&displayUpAttr,&displayUpThread);
      pthread_attr_init(&displayUpAttr);
      if(pthread_create(&displayUpId, &displayUpAttr, displayUpdtadeThread, this)) qDebug()<<"error creating thread";
      displayUpThread.sched_priority = 1;
      pthread_attr_setdetachstate(&displayReAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&displayReAttr,&displayReThread);
      pthread_attr_init(&displayReAttr);
      if(pthread_create(&displayReId, &displayReAttr, displayRefreshThread, this)) qDebug()<<"error creating thread";
      cameraThrea.sched_priority = 1;
      pthread_attr_setdetachstate(&cameraAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&cameraAttr,&cameraThrea);
      pthread_attr_init(&cameraAttr);
      if(pthread_create(&cameraID, &cameraAttr, cameraThread, this)) qDebug()<<"error creating thread";
      faceThread.sched_priority = 1;
      pthread_attr_setdetachstate(&faceAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&faceAttr,&faceThread);
      pthread_attr_init(&faceAttr);
      if(pthread_create(&faceID, &faceAttr, faceDetectionThread, this)) qDebug()<<"error creating thread";
      trainThrea.sched_priority = 1;
      pthread_attr_setdetachstate(&trainAttr, PTHREAD_CREATE_JOINABLE);
      pthread_attr_setschedparam(&trainAttr,&trainThrea);
      pthread_attr_init(&trainAttr);
      if(pthread_create(&trainID, &trainAttr, trainThread, this)) qDebug()<<"error creating thread";

}

void MainActivity::wait_pthreads()
{
    pthread_join(displayUpId,nullptr);
    pthread_join(displayReId,nullptr);
    pthread_join(cameraID,nullptr);
    pthread_join(trainID,nullptr);
    pthread_join(faceID,nullptr);
}

void MainActivity::timerHandler(int signo)
{
    if(signo == SIGALRM ){
        qDebug()<<"Timer overflow";
        if(act.i==0){
            pthread_mutex_lock(&act.timerTrainConditionMutex);
            pthread_cond_signal(&act.timerTrainCondition);
            pthread_mutex_unlock(&act.timerTrainConditionMutex);
        }
        if(act.i==1){
            pthread_mutex_lock(&act.timerUpConditionMutex);
            pthread_cond_signal(&act.timerUpCondition);
            pthread_mutex_unlock(&act.timerUpConditionMutex);}
        if(act.i==2){
            pthread_mutex_lock(&act.timerReConditionMutex);
            pthread_cond_signal(&act.timerReCondition);
            pthread_mutex_unlock(&act.timerReConditionMutex);
            act.i = 0;}
      act.i++;
    }

}

void MainActivity::displayUpdtadeFunction()
{
    emit get();
}

void MainActivity::displayRefreshFunction()
{
    emit refreshDisplay(communication->getMotor(),communication->getPm());
}

void MainActivity::postDatabaseCall(int aux)
{
    emit post(aux);
}

void *MainActivity::displayUpdtadeThread(void *)
{
    while(1){
        pthread_mutex_lock(&act.timerUpConditionMutex);
        pthread_cond_wait(&act.timerUpCondition,&act.timerUpConditionMutex);
        pthread_mutex_unlock(&act.timerUpConditionMutex);
        qDebug()<<"display update";
        act.displayUpdtadeFunction();
}}

void *MainActivity::displayRefreshThread(void *)
{
    while(1){
        pthread_mutex_lock(&act.timerReConditionMutex);
        pthread_cond_wait(&act.timerReCondition,&act.timerReConditionMutex);
        pthread_mutex_unlock(&act.timerReConditionMutex);
        qDebug()<<"display refresh";
        act.displayRefreshFunction();
}}

void *MainActivity::cameraThread(void *)
{
    while(1){
        pthread_mutex_lock(&act.takePhotoConditionMutex);
        pthread_cond_wait(&act.takePhotoCondition,&act.takePhotoConditionMutex);
        pthread_mutex_unlock(&act.takePhotoConditionMutex);
        qDebug()<<"cameraThread";
        if(act.camera->takePicture()){
            pthread_mutex_lock(&act.photoAvailableConditionMutex);
            pthread_cond_signal(&act.photoAvailableCondition);
            pthread_mutex_unlock(&act.photoAvailableConditionMutex);
        }
}}

void *MainActivity::faceDetectionThread(void *)
{   int aux = 0;
    int anterior = 6;
    while(1){
        pthread_mutex_lock(&act.photoAvailableConditionMutex);
        pthread_cond_wait(&act.photoAvailableCondition,&act.photoAvailableConditionMutex);
        pthread_mutex_unlock(&act.photoAvailableConditionMutex);
        qDebug()<<"faceThread";
        pthread_mutex_lock(&act.trainDoneConditionMutex);
        while(!act.trainOver)
        pthread_cond_wait(&act.trainDoneCondition,&act.trainDoneConditionMutex);
        pthread_mutex_unlock(&act.trainDoneConditionMutex);
        act.face->recognizer();
        if((act.face->getConfidence()< 50) && (act.face->getConfidence()!= 0)){
            qDebug() << "recognized";
            int fd0 = open("/dev/led0",O_WRONLY);
            char on='1';
            write(fd0,&on,1);
            close(fd0);
            aux = 4;

        }
        else{
           qDebug() << "not recognized";
           if(anterior == 3) aux = 6;
           else aux = 3;
           anterior = aux;
           }
        qDebug()<<"post:"<<aux;
        act.postDatabaseCall(aux);

    }}

void *MainActivity::trainThread(void *)
{   while(1){
        pthread_mutex_lock(&act.timerTrainConditionMutex);
        pthread_cond_wait(&act.timerTrainCondition,&act.timerTrainConditionMutex);
        pthread_mutex_unlock(&act.timerTrainConditionMutex);
        if(act.face->train()== true){
            pthread_mutex_lock(&act.trainDoneConditionMutex);
            pthread_cond_signal(&act.trainDoneCondition);
            act.trainOver = 1;
            pthread_mutex_unlock(&act.trainDoneConditionMutex);
        }
    }
}


 void  MainActivity::msqNotifyHandler(union sigval sv)
{
  mqd_t msq_id = *(static_cast<mqd_t*>(sv.sival_ptr));

  struct mq_attr attr;
  if(mq_getattr(msq_id, &attr) < 0)
  {
    qDebug() << "Error in mq_getattr " << strerror(errno)  << endl;
    return;
  }

  // Reregister for new messages on Q
  struct sigevent sev;
  sev.sigev_notify = SIGEV_THREAD;
  sev.sigev_notify_function = act.msqNotifyHandler;
  sev.sigev_notify_attributes = NULL;
  sev.sigev_value.sival_ptr = sv.sival_ptr;
  if (mq_notify(msq_id, &sev) < 0)
  {
    qDebug() << "Error during Reregister in msq_notify : "
         << strerror(errno) << endl;
    exit(EXIT_FAILURE);
  }

  // Read new message on the Q
  char* arr = new char[attr.mq_msgsize];
  memset(arr, 0, attr.mq_msgsize);
  if(mq_receive(msq_id, arr, attr.mq_msgsize, 0) < 0)
  {
    if(errno != EAGAIN)
    {
      qDebug() << "Error in mq_receive " << strerror(errno) << endl;
      exit(EXIT_FAILURE);
    }
  }
  else
  {
    qDebug() << "Msg rcvd " << arr << "n"<<atoi(arr)<< endl;
    if((atoi(arr) == 1) || (atoi(arr) == 2) ){
        pthread_mutex_lock(&act.takePhotoConditionMutex);
        pthread_cond_signal(&act.takePhotoCondition);
        pthread_mutex_unlock(&act.takePhotoConditionMutex);
    }
    if(atoi(arr) == 5){
        int fd0 = open("/dev/led0",O_WRONLY);
        char off='0';
        write(fd0,&off,1);
        close(fd0);
    }
  }
}
