#include "facerecognition.h"

FaceRecognition::FaceRecognition()
{

}
bool FaceRecognition::train()
{   qDebug()<< "inside the train";
    CascadeClassifier classifier;
    classifier.load("haarcascade_frontalface_alt_tree.xml");
    Mat picture;
    vector<cv::String> fn;
    vector<int> labels;
    glob("./data/*.jpg", fn, false);
    vector<Mat> images;
    Mat frame1;
    size_t count = fn.size(); //number of png files in images folder
    for (size_t i=0; i<count; i++){
        qDebug()<<"reading"<<i;
        picture=imread(fn[i]);
        cvtColor(picture, frame1, 6);
        vector<Rect> faces;
        classifier.detectMultiScale(frame1, faces, 1.2, 5);
        cout << faces.size() << endl;
        for(size_t k = 0; k < faces.size(); k++){
             Mat face = frame1(faces[k]);
             images.push_back(face);
             labels.push_back(0);}}
     model->train(images, labels);
     if((images.size()!=0) && (labels.size()!=0))
         qDebug() << "Treino bem feito" << endl;
     else  qDebug() << "Treino mal feito" << endl;
     return true;
}
void FaceRecognition::recognizer()
{
    qDebug()<<"na funcao recognizer";
    CascadeClassifier m_classifier;
    m_classifier.load("haarcascade_frontalface_default.xml");
    Mat windowFrame;
    Mat frame = imread("camera.jpg");
    if (!frame.empty())
        qDebug() << "go go" << endl;
    if (frame.empty())
    {
        qDebug() << "Could not open or find the image" << endl;
     }

    cvtColor(frame, windowFrame, 6);
    vector<Rect> faces;
    m_classifier.detectMultiScale(frame, faces, 1.2, 5);
    qDebug() << faces.size() << endl;
    confidence = 0.0;
    for(size_t i = 0; i < faces.size(); i++){
        rectangle(frame, faces[i], Scalar(0, 255, 0));
        Mat face = windowFrame(faces[i]);
        //int predicted = model->predict(face);
        int predicted  = 0;
        model->predict(face, predicted, confidence);
        /*if(labels.find(predicted) == labels.end() || confidence < 25)
           qDebug() << "unknown" << endl;
        else qDebug() << "eureka" << endl;*/
        qDebug() << "ID: " << predicted << " ^Confidence: " << confidence << endl;

    }}

double FaceRecognition::getConfidence()
{
    return confidence;
}
