#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QObject>
#include "display.h"
#include "mainactivity.h"
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
//#define MSG_Q_NAME "/MY_MSGQ_3"
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    QQmlContext* ctx = engine.rootContext(); 
    /*********** Device Driver - close a left open car ***********/
    int fd0 = open("/dev/led0",O_WRONLY);
    qDebug()<<"open:"<<fd0;
    char on='0';
    write(fd0,&on,1);
    close(fd0);
    /*********** Notify From Daemon Messague Queue ***********/
    mqd_t msq_id = mq_open(MSG_Q_NAME, O_RDONLY | O_NONBLOCK | O_CREAT, 0666, 0);
    if(msq_id == (mqd_t) -1)
    {
        qDebug()<<"Error on msg Q creation: " << strerror(errno) << endl;
        exit(EXIT_FAILURE);
    }

      // The process is registered for notification for new message on the Q
     struct sigevent sev;
     sev.sigev_notify = SIGEV_THREAD;
     sev.sigev_notify_function = act.msqNotifyHandler;
     sev.sigev_notify_attributes = NULL;
     sev.sigev_value.sival_ptr = &msq_id;

     if (mq_notify(msq_id, &sev) < 0)
     {
        qDebug() << "Error on msg Q notify : " << strerror(errno) << endl;
        exit(EXIT_FAILURE);
      }
      else qDebug() << "Notify for msg Q reception " << MSG_Q_NAME << endl;



      ssize_t n = 0;
      struct mq_attr attr;
      if(mq_getattr(msq_id, &attr) < 0)
      {
        qDebug() << "Error in mq_getattr " << strerror(errno)  << endl;
        exit(EXIT_FAILURE);
      }
      char* arr = new char[attr.mq_msgsize];
      memset(arr, 0, attr.mq_msgsize);
      while((n = mq_receive(msq_id, arr, attr.mq_msgsize, 0) >= 0))
      {
        qDebug() << "Empty the Q. Msg rcvd " << arr << endl;
      }

      /*********** Set TIMER ***********/
      struct itimerval itv;
      signal(SIGALRM,act.timerHandler);
      itv.it_interval.tv_sec = 10;
      itv.it_interval.tv_usec = 0;
      itv.it_value.tv_sec = 10;
      itv.it_value.tv_usec = 0;
      setitimer(ITIMER_REAL,&itv,NULL);


      ctx->setContextProperty("display",&act);

      const QUrl url(QStringLiteral("qrc:/main.qml"));

      engine.load(url);

      if(engine.rootObjects().isEmpty())
       return -1;
      return app.exec();

}
