#ifndef FACERECOGNITION_H
#define FACERECOGNITION_H

#include <QObject>
#include <opencv2/opencv.hpp>
#include <QDebug>
#include <fstream>
#include <map>
using namespace cv;
using namespace std;
class FaceRecognition: public QObject
{
    Q_OBJECT
public:
    FaceRecognition();
    void recognizer();
    double getConfidence();
private:
    double confidence;
    Ptr<FaceRecognizer> model = createLBPHFaceRecognizer();
    void train();
};

#endif // FACERECOGNITION_H
