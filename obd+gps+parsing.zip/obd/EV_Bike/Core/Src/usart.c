/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */

#define TBUF_SIZE 128
#define RBUF_SIZE 128
#define RBUFFOUR_SIZE 255
static  uint8_t TxBuff [TBUF_SIZE];
static  uint8_t RxBuff [RBUF_SIZE];
static volatile uint8_t TxWriteIndex = 0 ;
static volatile uint8_t TxReadIndex  = 0 ;
static volatile uint8_t RxWriteIndex = 0 ;
static volatile uint8_t RxReadIndex  = 0 ;
static char ti_restart = 1 ;
static volatile uint8_t RxWriteIndexSix = 0 ;
static  uint8_t RxBuffSix [RBUF_SIZE];


static  uint8_t TxBuffFour [TBUF_SIZE];
static  uint8_t RxBuffFour [RBUFFOUR_SIZE];
static volatile uint8_t TxWriteIndexFour = 0 ;
static volatile uint8_t TxReadIndexFour  = 0 ;
static volatile uint8_t RxWriteIndexFour = 0 ;
static volatile uint8_t RxReadIndexFour  = 0 ;
static char ti_restartFour = 1 ;
uint8_t bt;
uint8_t volatile usart4_flag = 0;
//_--------------------------------------------------------------


//UART3 RX data structures
uint8_t UART3Rx_Buffer[128];
uint8_t Rx_Buffer[128];
int receve_flag = 0;
volatile uint8_t UART3Rx_index = 0;
/* USER CODE END 0 */

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;
DMA_HandleTypeDef hdma_uart4_rx;

/* UART4 init function */
void MX_UART4_Init(void)
{

  huart4.Instance = UART4;
  huart4.Init.BaudRate = 9600;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART3 init function */

void MX_USART3_UART_Init(void)
{

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }

}
/* USART6 init function */

void MX_USART6_UART_Init(void)
{

  huart6.Instance = USART6;
  huart6.Init.BaudRate = 9600;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  huart6.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart6.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspInit 0 */

  /* USER CODE END UART4_MspInit 0 */
    /* UART4 clock enable */
    __HAL_RCC_UART4_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**UART4 GPIO Configuration
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART4;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* UART4 DMA Init */
    /* UART4_RX Init */
    hdma_uart4_rx.Instance = DMA1_Stream2;
    hdma_uart4_rx.Init.Channel = DMA_CHANNEL_4;
    hdma_uart4_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_uart4_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_uart4_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_uart4_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_uart4_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_uart4_rx.Init.Mode = DMA_CIRCULAR;
    hdma_uart4_rx.Init.Priority = DMA_PRIORITY_LOW;
    hdma_uart4_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_uart4_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_uart4_rx);

    /* UART4 interrupt Init */
    HAL_NVIC_SetPriority(UART4_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspInit 1 */

  /* USER CODE END UART4_MspInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspInit 0 */

  /* USER CODE END USART3_MspInit 0 */
    /* USART3 clock enable */
    __HAL_RCC_USART3_CLK_ENABLE();

    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**USART3 GPIO Configuration
    PD8     ------> USART3_TX
    PD9     ------> USART3_RX
    */
    GPIO_InitStruct.Pin = STLK_RX_Pin|STLK_TX_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USART3 interrupt Init */
    HAL_NVIC_SetPriority(USART3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspInit 1 */

  /* USER CODE END USART3_MspInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspInit 0 */

  /* USER CODE END USART6_MspInit 0 */
    /* USART6 clock enable */
    __HAL_RCC_USART6_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_USART6;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART6 interrupt Init */
    HAL_NVIC_SetPriority(USART6_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspInit 1 */

  /* USER CODE END USART6_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspDeInit 0 */

  /* USER CODE END UART4_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_UART4_CLK_DISABLE();

    /**UART4 GPIO Configuration
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_10|GPIO_PIN_11);

    /* UART4 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmarx);

    /* UART4 interrupt Deinit */
    HAL_NVIC_DisableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspDeInit 1 */

  /* USER CODE END UART4_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspDeInit 0 */

  /* USER CODE END USART3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART3_CLK_DISABLE();

    /**USART3 GPIO Configuration
    PD8     ------> USART3_TX
    PD9     ------> USART3_RX
    */
    HAL_GPIO_DeInit(GPIOD, STLK_RX_Pin|STLK_TX_Pin);

    /* USART3 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspDeInit 1 */

  /* USER CODE END USART3_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspDeInit 0 */

  /* USER CODE END USART6_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART6_CLK_DISABLE();

    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6|GPIO_PIN_7);

    /* USART6 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspDeInit 1 */

  /* USER CODE END USART6_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
//------UART3--------
#pragma disable 
int uart_putchar ( unsigned char c)
{
	if(uart_get_txbufsize() >= TBUF_SIZE) return (-ENOBUFS);
	TxBuff [TxWriteIndex & (TBUF_SIZE -1)]= c ;
	TxWriteIndex++;
	if (ti_restart)
	{ 
		ti_restart=0;
	  HAL_UART_Transmit_IT(&huart3,&TxBuff[TxReadIndex & (TBUF_SIZE-1)], 1);
		TxReadIndex++;
	}
	return 0;
}


#pragma disable 
int uart_getchar(void)
{
	if(uart_get_rxbufsize()==0)  return (-ENODATA);
	return (RxBuff[(RxReadIndex++) & (RBUF_SIZE -1)]);
}

#pragma disable 
uint8_t uart_get_rxbufsize(void)
{
	return ( RxWriteIndex - RxReadIndex);
}
#pragma disable 
uint8_t uart_get_txbufsize(void)
{
	return ( TxWriteIndex - TxReadIndex);
}









//-----------UART4------------
#pragma disable 
uint8_t uart_get_rxbufsizeFour(void)
{
	if(RxReadIndexFour == 254){
		RxReadIndexFour = 0;
	  RxWriteIndexFour = 0;}
	return ( RxWriteIndexFour - RxReadIndexFour);
}

#pragma disable 
uint8_t uart_get_txbufsizeFour(void)
{
	return ( TxWriteIndexFour - TxReadIndexFour);
}
#pragma disable 
int uart_putcharFour ( unsigned char c)
{
	if(uart_get_txbufsizeFour() >= TBUF_SIZE) return (-ENOBUFS);
	TxBuffFour [TxWriteIndexFour & (TBUF_SIZE -1)]= c ;
	TxWriteIndexFour++;
	if (ti_restartFour)
	{ 
		ti_restartFour=0;
	  HAL_UART_Transmit_IT(&huart4,&TxBuffFour[TxReadIndexFour & (TBUF_SIZE-1)], 1);
		TxReadIndexFour++;
	}
	return 0;
}



#pragma disable 
int uart_getcharFour(void)
{
	if(uart_get_rxbufsizeFour()==0)  return (-ENODATA);
	return (RxBuffFour[(RxReadIndexFour++) & (RBUF_SIZE -1)]);
}



//-----------------------------------------------------
void init_UART3(){
	// set the interrupt for UART3 Rx
	HAL_UART_Receive_IT(&huart3,&RxBuff[RxWriteIndex], 1);
	HAL_UART_Receive_IT(&huart6,&RxBuffSix[RxWriteIndexSix], 1); 
	//HAL_UART_Receive_IT(&huart4,&RxBuffFour[RxWriteIndexFour], 1); 
  HAL_UART_Receive_DMA(&huart4,&RxBuffFour[RxWriteIndexFour], 255);	 
}

//implemantation of UART ISR
void HAL_UART_RxCpltCallback(UART_HandleTypeDef* huart){
	if (huart->Instance == USART3){ 
		RxWriteIndex ++ ;
		HAL_UART_Receive_IT(&huart3, &RxBuff[RxWriteIndex  & (RBUF_SIZE-1)], 1);
		//Flag or condition variable to warn the system that something was received, then go to the task and process that data
	}
	
	if (huart->Instance == USART6){ 

		}
	if (huart->Instance == UART4){
		RxWriteIndexFour = 254;		

		HAL_UART_Receive_DMA(&huart4, &RxBuffFour[RxWriteIndexFour], 255);
		uart_putchar('c');

	}

}
#pragma disable 
void pauseDMA(void){
//HAL_UART_DMAPause	(&huart4); 
	//HAL_DMA_Abort	(&hdma_uart4_rx);
	 HAL_UART_DMAPause	(	&huart4);	

}
#pragma disable 
void resumeDMA(void){
		HAL_UART_DMAResume	(	&huart4	);
}

void HAL_UART_TxCpltCallback (UART_HandleTypeDef *huart){

		if (huart->Instance == USART3){ 
		if(uart_get_txbufsize() !=0){
			ti_restart=0;
			HAL_UART_Transmit_IT(&huart3,&TxBuff[TxReadIndex & (TBUF_SIZE-1)], 1);
			TxReadIndex ++;
		}
		else 
			ti_restart=1;
	}

		if (huart->Instance == UART4){ 
		if(uart_get_txbufsizeFour() !=0){
			ti_restartFour=0;
			HAL_UART_Transmit_IT(&huart4,&TxBuffFour[TxReadIndexFour & (TBUF_SIZE-1)], 1);
			TxReadIndexFour ++;
		}
		else 
			ti_restartFour=1;
	}
}


void newMessage(){
	static int local_index = 0;
	int out_index = 0;
	while(local_index != RxWriteIndex){
		Rx_Buffer[out_index] = RxBuff[local_index];
		printf("%c",Rx_Buffer[out_index]);
		out_index++;
		local_index++;
		local_index &= ~(1<<7);
		receve_flag = 1;
	}
	Rx_Buffer[out_index] = '\0';
}

//redifine the stdout
int fputc(int ch, FILE *f){
	HAL_UART_Transmit(&huart3, (uint8_t*)&ch, 1, 100);
	return ch;
}
/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
